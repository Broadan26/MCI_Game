gdjs.Info04Code = {};
gdjs.Info04Code.GDFloorTileObjects1= [];
gdjs.Info04Code.GDFloorTileObjects2= [];
gdjs.Info04Code.GDCliffRightObjects1= [];
gdjs.Info04Code.GDCliffRightObjects2= [];
gdjs.Info04Code.GDWallRightObjects1= [];
gdjs.Info04Code.GDWallRightObjects2= [];
gdjs.Info04Code.GDCliffLeftObjects1= [];
gdjs.Info04Code.GDCliffLeftObjects2= [];
gdjs.Info04Code.GDWallLeftObjects1= [];
gdjs.Info04Code.GDWallLeftObjects2= [];
gdjs.Info04Code.GDCeilLeftObjects1= [];
gdjs.Info04Code.GDCeilLeftObjects2= [];
gdjs.Info04Code.GDCeilTileObjects1= [];
gdjs.Info04Code.GDCeilTileObjects2= [];
gdjs.Info04Code.GDCeilRightObjects1= [];
gdjs.Info04Code.GDCeilRightObjects2= [];
gdjs.Info04Code.GDCornerBRObjects1= [];
gdjs.Info04Code.GDCornerBRObjects2= [];
gdjs.Info04Code.GDCornerBLObjects1= [];
gdjs.Info04Code.GDCornerBLObjects2= [];
gdjs.Info04Code.GDCornerTLObjects1= [];
gdjs.Info04Code.GDCornerTLObjects2= [];
gdjs.Info04Code.GDCornerTRObjects1= [];
gdjs.Info04Code.GDCornerTRObjects2= [];
gdjs.Info04Code.GDHoverTileHorizontalObjects1= [];
gdjs.Info04Code.GDHoverTileHorizontalObjects2= [];
gdjs.Info04Code.GDHoverTileRObjects1= [];
gdjs.Info04Code.GDHoverTileRObjects2= [];
gdjs.Info04Code.GDHoverTileLObjects1= [];
gdjs.Info04Code.GDHoverTileLObjects2= [];
gdjs.Info04Code.GDTileObjects1= [];
gdjs.Info04Code.GDTileObjects2= [];
gdjs.Info04Code.GDBGTileObjects1= [];
gdjs.Info04Code.GDBGTileObjects2= [];
gdjs.Info04Code.GDDescObjects1= [];
gdjs.Info04Code.GDDescObjects2= [];
gdjs.Info04Code.GDNewObjectObjects1= [];
gdjs.Info04Code.GDNewObjectObjects2= [];

gdjs.Info04Code.conditionTrue_0 = {val:false};
gdjs.Info04Code.condition0IsTrue_0 = {val:false};
gdjs.Info04Code.condition1IsTrue_0 = {val:false};
gdjs.Info04Code.condition2IsTrue_0 = {val:false};


gdjs.Info04Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.Info04Code.GDDescObjects1);
{for(var i = 0, len = gdjs.Info04Code.GDDescObjects1.length ;i < len;++i) {
    gdjs.Info04Code.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.Info04Code.condition0IsTrue_0.val = false;
{
gdjs.Info04Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.Info04Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level05", false);
}}

}


{


gdjs.Info04Code.condition0IsTrue_0.val = false;
{
gdjs.Info04Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Info04Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Info04Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Info04Code.GDFloorTileObjects1.length = 0;
gdjs.Info04Code.GDFloorTileObjects2.length = 0;
gdjs.Info04Code.GDCliffRightObjects1.length = 0;
gdjs.Info04Code.GDCliffRightObjects2.length = 0;
gdjs.Info04Code.GDWallRightObjects1.length = 0;
gdjs.Info04Code.GDWallRightObjects2.length = 0;
gdjs.Info04Code.GDCliffLeftObjects1.length = 0;
gdjs.Info04Code.GDCliffLeftObjects2.length = 0;
gdjs.Info04Code.GDWallLeftObjects1.length = 0;
gdjs.Info04Code.GDWallLeftObjects2.length = 0;
gdjs.Info04Code.GDCeilLeftObjects1.length = 0;
gdjs.Info04Code.GDCeilLeftObjects2.length = 0;
gdjs.Info04Code.GDCeilTileObjects1.length = 0;
gdjs.Info04Code.GDCeilTileObjects2.length = 0;
gdjs.Info04Code.GDCeilRightObjects1.length = 0;
gdjs.Info04Code.GDCeilRightObjects2.length = 0;
gdjs.Info04Code.GDCornerBRObjects1.length = 0;
gdjs.Info04Code.GDCornerBRObjects2.length = 0;
gdjs.Info04Code.GDCornerBLObjects1.length = 0;
gdjs.Info04Code.GDCornerBLObjects2.length = 0;
gdjs.Info04Code.GDCornerTLObjects1.length = 0;
gdjs.Info04Code.GDCornerTLObjects2.length = 0;
gdjs.Info04Code.GDCornerTRObjects1.length = 0;
gdjs.Info04Code.GDCornerTRObjects2.length = 0;
gdjs.Info04Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Info04Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Info04Code.GDHoverTileRObjects1.length = 0;
gdjs.Info04Code.GDHoverTileRObjects2.length = 0;
gdjs.Info04Code.GDHoverTileLObjects1.length = 0;
gdjs.Info04Code.GDHoverTileLObjects2.length = 0;
gdjs.Info04Code.GDTileObjects1.length = 0;
gdjs.Info04Code.GDTileObjects2.length = 0;
gdjs.Info04Code.GDBGTileObjects1.length = 0;
gdjs.Info04Code.GDBGTileObjects2.length = 0;
gdjs.Info04Code.GDDescObjects1.length = 0;
gdjs.Info04Code.GDDescObjects2.length = 0;
gdjs.Info04Code.GDNewObjectObjects1.length = 0;
gdjs.Info04Code.GDNewObjectObjects2.length = 0;

gdjs.Info04Code.eventsList0(runtimeScene);
return;

}

gdjs['Info04Code'] = gdjs.Info04Code;
