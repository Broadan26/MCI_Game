gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDFloorTileObjects1= [];
gdjs.MainMenuCode.GDFloorTileObjects2= [];
gdjs.MainMenuCode.GDCliffRightObjects1= [];
gdjs.MainMenuCode.GDCliffRightObjects2= [];
gdjs.MainMenuCode.GDWallRightObjects1= [];
gdjs.MainMenuCode.GDWallRightObjects2= [];
gdjs.MainMenuCode.GDCliffLeftObjects1= [];
gdjs.MainMenuCode.GDCliffLeftObjects2= [];
gdjs.MainMenuCode.GDWallLeftObjects1= [];
gdjs.MainMenuCode.GDWallLeftObjects2= [];
gdjs.MainMenuCode.GDCeilLeftObjects1= [];
gdjs.MainMenuCode.GDCeilLeftObjects2= [];
gdjs.MainMenuCode.GDCeilTileObjects1= [];
gdjs.MainMenuCode.GDCeilTileObjects2= [];
gdjs.MainMenuCode.GDCeilRightObjects1= [];
gdjs.MainMenuCode.GDCeilRightObjects2= [];
gdjs.MainMenuCode.GDCornerBRObjects1= [];
gdjs.MainMenuCode.GDCornerBRObjects2= [];
gdjs.MainMenuCode.GDCornerBLObjects1= [];
gdjs.MainMenuCode.GDCornerBLObjects2= [];
gdjs.MainMenuCode.GDCornerTLObjects1= [];
gdjs.MainMenuCode.GDCornerTLObjects2= [];
gdjs.MainMenuCode.GDCornerTRObjects1= [];
gdjs.MainMenuCode.GDCornerTRObjects2= [];
gdjs.MainMenuCode.GDHoverTileHorizontalObjects1= [];
gdjs.MainMenuCode.GDHoverTileHorizontalObjects2= [];
gdjs.MainMenuCode.GDHoverTileRObjects1= [];
gdjs.MainMenuCode.GDHoverTileRObjects2= [];
gdjs.MainMenuCode.GDHoverTileLObjects1= [];
gdjs.MainMenuCode.GDHoverTileLObjects2= [];
gdjs.MainMenuCode.GDTileObjects1= [];
gdjs.MainMenuCode.GDTileObjects2= [];
gdjs.MainMenuCode.GDBGTileObjects1= [];
gdjs.MainMenuCode.GDBGTileObjects2= [];
gdjs.MainMenuCode.GDSpermyObjects1= [];
gdjs.MainMenuCode.GDSpermyObjects2= [];
gdjs.MainMenuCode.GDTitleObjects1= [];
gdjs.MainMenuCode.GDTitleObjects2= [];
gdjs.MainMenuCode.GDStartGameObjects1= [];
gdjs.MainMenuCode.GDStartGameObjects2= [];
gdjs.MainMenuCode.GDNewObjectObjects1= [];
gdjs.MainMenuCode.GDNewObjectObjects2= [];
gdjs.MainMenuCode.GDBGObjects1= [];
gdjs.MainMenuCode.GDBGObjects2= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};


gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("StartGame"), gdjs.MainMenuCode.GDStartGameObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.MainMenuCode.GDTitleObjects1);
{for(var i = 0, len = gdjs.MainMenuCode.GDTitleObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDTitleObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.MainMenuCode.GDStartGameObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartGameObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Music\\MainMenuSong.wav", true, 100, 1);
}}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDFloorTileObjects1.length = 0;
gdjs.MainMenuCode.GDFloorTileObjects2.length = 0;
gdjs.MainMenuCode.GDCliffRightObjects1.length = 0;
gdjs.MainMenuCode.GDCliffRightObjects2.length = 0;
gdjs.MainMenuCode.GDWallRightObjects1.length = 0;
gdjs.MainMenuCode.GDWallRightObjects2.length = 0;
gdjs.MainMenuCode.GDCliffLeftObjects1.length = 0;
gdjs.MainMenuCode.GDCliffLeftObjects2.length = 0;
gdjs.MainMenuCode.GDWallLeftObjects1.length = 0;
gdjs.MainMenuCode.GDWallLeftObjects2.length = 0;
gdjs.MainMenuCode.GDCeilLeftObjects1.length = 0;
gdjs.MainMenuCode.GDCeilLeftObjects2.length = 0;
gdjs.MainMenuCode.GDCeilTileObjects1.length = 0;
gdjs.MainMenuCode.GDCeilTileObjects2.length = 0;
gdjs.MainMenuCode.GDCeilRightObjects1.length = 0;
gdjs.MainMenuCode.GDCeilRightObjects2.length = 0;
gdjs.MainMenuCode.GDCornerBRObjects1.length = 0;
gdjs.MainMenuCode.GDCornerBRObjects2.length = 0;
gdjs.MainMenuCode.GDCornerBLObjects1.length = 0;
gdjs.MainMenuCode.GDCornerBLObjects2.length = 0;
gdjs.MainMenuCode.GDCornerTLObjects1.length = 0;
gdjs.MainMenuCode.GDCornerTLObjects2.length = 0;
gdjs.MainMenuCode.GDCornerTRObjects1.length = 0;
gdjs.MainMenuCode.GDCornerTRObjects2.length = 0;
gdjs.MainMenuCode.GDHoverTileHorizontalObjects1.length = 0;
gdjs.MainMenuCode.GDHoverTileHorizontalObjects2.length = 0;
gdjs.MainMenuCode.GDHoverTileRObjects1.length = 0;
gdjs.MainMenuCode.GDHoverTileRObjects2.length = 0;
gdjs.MainMenuCode.GDHoverTileLObjects1.length = 0;
gdjs.MainMenuCode.GDHoverTileLObjects2.length = 0;
gdjs.MainMenuCode.GDTileObjects1.length = 0;
gdjs.MainMenuCode.GDTileObjects2.length = 0;
gdjs.MainMenuCode.GDBGTileObjects1.length = 0;
gdjs.MainMenuCode.GDBGTileObjects2.length = 0;
gdjs.MainMenuCode.GDSpermyObjects1.length = 0;
gdjs.MainMenuCode.GDSpermyObjects2.length = 0;
gdjs.MainMenuCode.GDTitleObjects1.length = 0;
gdjs.MainMenuCode.GDTitleObjects2.length = 0;
gdjs.MainMenuCode.GDStartGameObjects1.length = 0;
gdjs.MainMenuCode.GDStartGameObjects2.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects1.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects2.length = 0;
gdjs.MainMenuCode.GDBGObjects1.length = 0;
gdjs.MainMenuCode.GDBGObjects2.length = 0;

gdjs.MainMenuCode.eventsList0(runtimeScene);
return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
