gdjs.Info02Code = {};
gdjs.Info02Code.GDFloorTileObjects1= [];
gdjs.Info02Code.GDFloorTileObjects2= [];
gdjs.Info02Code.GDCliffRightObjects1= [];
gdjs.Info02Code.GDCliffRightObjects2= [];
gdjs.Info02Code.GDWallRightObjects1= [];
gdjs.Info02Code.GDWallRightObjects2= [];
gdjs.Info02Code.GDCliffLeftObjects1= [];
gdjs.Info02Code.GDCliffLeftObjects2= [];
gdjs.Info02Code.GDWallLeftObjects1= [];
gdjs.Info02Code.GDWallLeftObjects2= [];
gdjs.Info02Code.GDCeilLeftObjects1= [];
gdjs.Info02Code.GDCeilLeftObjects2= [];
gdjs.Info02Code.GDCeilTileObjects1= [];
gdjs.Info02Code.GDCeilTileObjects2= [];
gdjs.Info02Code.GDCeilRightObjects1= [];
gdjs.Info02Code.GDCeilRightObjects2= [];
gdjs.Info02Code.GDCornerBRObjects1= [];
gdjs.Info02Code.GDCornerBRObjects2= [];
gdjs.Info02Code.GDCornerBLObjects1= [];
gdjs.Info02Code.GDCornerBLObjects2= [];
gdjs.Info02Code.GDCornerTLObjects1= [];
gdjs.Info02Code.GDCornerTLObjects2= [];
gdjs.Info02Code.GDCornerTRObjects1= [];
gdjs.Info02Code.GDCornerTRObjects2= [];
gdjs.Info02Code.GDHoverTileHorizontalObjects1= [];
gdjs.Info02Code.GDHoverTileHorizontalObjects2= [];
gdjs.Info02Code.GDHoverTileRObjects1= [];
gdjs.Info02Code.GDHoverTileRObjects2= [];
gdjs.Info02Code.GDHoverTileLObjects1= [];
gdjs.Info02Code.GDHoverTileLObjects2= [];
gdjs.Info02Code.GDTileObjects1= [];
gdjs.Info02Code.GDTileObjects2= [];
gdjs.Info02Code.GDBGTileObjects1= [];
gdjs.Info02Code.GDBGTileObjects2= [];
gdjs.Info02Code.GDDescObjects1= [];
gdjs.Info02Code.GDDescObjects2= [];
gdjs.Info02Code.GDNewObjectObjects1= [];
gdjs.Info02Code.GDNewObjectObjects2= [];

gdjs.Info02Code.conditionTrue_0 = {val:false};
gdjs.Info02Code.condition0IsTrue_0 = {val:false};
gdjs.Info02Code.condition1IsTrue_0 = {val:false};
gdjs.Info02Code.condition2IsTrue_0 = {val:false};


gdjs.Info02Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.Info02Code.GDDescObjects1);
{for(var i = 0, len = gdjs.Info02Code.GDDescObjects1.length ;i < len;++i) {
    gdjs.Info02Code.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.Info02Code.condition0IsTrue_0.val = false;
{
gdjs.Info02Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.Info02Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level03", false);
}}

}


{


gdjs.Info02Code.condition0IsTrue_0.val = false;
{
gdjs.Info02Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Info02Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Info02Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Info02Code.GDFloorTileObjects1.length = 0;
gdjs.Info02Code.GDFloorTileObjects2.length = 0;
gdjs.Info02Code.GDCliffRightObjects1.length = 0;
gdjs.Info02Code.GDCliffRightObjects2.length = 0;
gdjs.Info02Code.GDWallRightObjects1.length = 0;
gdjs.Info02Code.GDWallRightObjects2.length = 0;
gdjs.Info02Code.GDCliffLeftObjects1.length = 0;
gdjs.Info02Code.GDCliffLeftObjects2.length = 0;
gdjs.Info02Code.GDWallLeftObjects1.length = 0;
gdjs.Info02Code.GDWallLeftObjects2.length = 0;
gdjs.Info02Code.GDCeilLeftObjects1.length = 0;
gdjs.Info02Code.GDCeilLeftObjects2.length = 0;
gdjs.Info02Code.GDCeilTileObjects1.length = 0;
gdjs.Info02Code.GDCeilTileObjects2.length = 0;
gdjs.Info02Code.GDCeilRightObjects1.length = 0;
gdjs.Info02Code.GDCeilRightObjects2.length = 0;
gdjs.Info02Code.GDCornerBRObjects1.length = 0;
gdjs.Info02Code.GDCornerBRObjects2.length = 0;
gdjs.Info02Code.GDCornerBLObjects1.length = 0;
gdjs.Info02Code.GDCornerBLObjects2.length = 0;
gdjs.Info02Code.GDCornerTLObjects1.length = 0;
gdjs.Info02Code.GDCornerTLObjects2.length = 0;
gdjs.Info02Code.GDCornerTRObjects1.length = 0;
gdjs.Info02Code.GDCornerTRObjects2.length = 0;
gdjs.Info02Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Info02Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Info02Code.GDHoverTileRObjects1.length = 0;
gdjs.Info02Code.GDHoverTileRObjects2.length = 0;
gdjs.Info02Code.GDHoverTileLObjects1.length = 0;
gdjs.Info02Code.GDHoverTileLObjects2.length = 0;
gdjs.Info02Code.GDTileObjects1.length = 0;
gdjs.Info02Code.GDTileObjects2.length = 0;
gdjs.Info02Code.GDBGTileObjects1.length = 0;
gdjs.Info02Code.GDBGTileObjects2.length = 0;
gdjs.Info02Code.GDDescObjects1.length = 0;
gdjs.Info02Code.GDDescObjects2.length = 0;
gdjs.Info02Code.GDNewObjectObjects1.length = 0;
gdjs.Info02Code.GDNewObjectObjects2.length = 0;

gdjs.Info02Code.eventsList0(runtimeScene);
return;

}

gdjs['Info02Code'] = gdjs.Info02Code;
