gdjs.Level03Code = {};
gdjs.Level03Code.GDKidneyStoneSpikesObjects1_1final = [];

gdjs.Level03Code.GDPlayerObjects1_1final = [];

gdjs.Level03Code.GDRestartObjects1_1final = [];

gdjs.Level03Code.GDFloorTileObjects1= [];
gdjs.Level03Code.GDFloorTileObjects2= [];
gdjs.Level03Code.GDCliffRightObjects1= [];
gdjs.Level03Code.GDCliffRightObjects2= [];
gdjs.Level03Code.GDWallRightObjects1= [];
gdjs.Level03Code.GDWallRightObjects2= [];
gdjs.Level03Code.GDCliffLeftObjects1= [];
gdjs.Level03Code.GDCliffLeftObjects2= [];
gdjs.Level03Code.GDWallLeftObjects1= [];
gdjs.Level03Code.GDWallLeftObjects2= [];
gdjs.Level03Code.GDCeilLeftObjects1= [];
gdjs.Level03Code.GDCeilLeftObjects2= [];
gdjs.Level03Code.GDCeilTileObjects1= [];
gdjs.Level03Code.GDCeilTileObjects2= [];
gdjs.Level03Code.GDCeilRightObjects1= [];
gdjs.Level03Code.GDCeilRightObjects2= [];
gdjs.Level03Code.GDCornerBRObjects1= [];
gdjs.Level03Code.GDCornerBRObjects2= [];
gdjs.Level03Code.GDCornerBLObjects1= [];
gdjs.Level03Code.GDCornerBLObjects2= [];
gdjs.Level03Code.GDCornerTLObjects1= [];
gdjs.Level03Code.GDCornerTLObjects2= [];
gdjs.Level03Code.GDCornerTRObjects1= [];
gdjs.Level03Code.GDCornerTRObjects2= [];
gdjs.Level03Code.GDHoverTileHorizontalObjects1= [];
gdjs.Level03Code.GDHoverTileHorizontalObjects2= [];
gdjs.Level03Code.GDHoverTileRObjects1= [];
gdjs.Level03Code.GDHoverTileRObjects2= [];
gdjs.Level03Code.GDHoverTileLObjects1= [];
gdjs.Level03Code.GDHoverTileLObjects2= [];
gdjs.Level03Code.GDTileObjects1= [];
gdjs.Level03Code.GDTileObjects2= [];
gdjs.Level03Code.GDBGTileObjects1= [];
gdjs.Level03Code.GDBGTileObjects2= [];
gdjs.Level03Code.GDPlayerObjects1= [];
gdjs.Level03Code.GDPlayerObjects2= [];
gdjs.Level03Code.GDTileBaseObjects1= [];
gdjs.Level03Code.GDTileBaseObjects2= [];
gdjs.Level03Code.GDEndObjects1= [];
gdjs.Level03Code.GDEndObjects2= [];
gdjs.Level03Code.GDRestartObjects1= [];
gdjs.Level03Code.GDRestartObjects2= [];
gdjs.Level03Code.GDWallObjects1= [];
gdjs.Level03Code.GDWallObjects2= [];
gdjs.Level03Code.GDLabelObjects1= [];
gdjs.Level03Code.GDLabelObjects2= [];
gdjs.Level03Code.GDElevatorObjects1= [];
gdjs.Level03Code.GDElevatorObjects2= [];
gdjs.Level03Code.GDMovingPlatObjects1= [];
gdjs.Level03Code.GDMovingPlatObjects2= [];
gdjs.Level03Code.GDEnemyObjects1= [];
gdjs.Level03Code.GDEnemyObjects2= [];
gdjs.Level03Code.GDLeftBlockObjects1= [];
gdjs.Level03Code.GDLeftBlockObjects2= [];
gdjs.Level03Code.GDRightBlockObjects1= [];
gdjs.Level03Code.GDRightBlockObjects2= [];
gdjs.Level03Code.GDUpBlockObjects1= [];
gdjs.Level03Code.GDUpBlockObjects2= [];
gdjs.Level03Code.GDDownBlockObjects1= [];
gdjs.Level03Code.GDDownBlockObjects2= [];
gdjs.Level03Code.GDScoreObjects1= [];
gdjs.Level03Code.GDScoreObjects2= [];
gdjs.Level03Code.GDLivesObjects1= [];
gdjs.Level03Code.GDLivesObjects2= [];
gdjs.Level03Code.GDKidneyStoneSpikesObjects1= [];
gdjs.Level03Code.GDKidneyStoneSpikesObjects2= [];
gdjs.Level03Code.GDEnemy1Objects1= [];
gdjs.Level03Code.GDEnemy1Objects2= [];

gdjs.Level03Code.conditionTrue_0 = {val:false};
gdjs.Level03Code.condition0IsTrue_0 = {val:false};
gdjs.Level03Code.condition1IsTrue_0 = {val:false};
gdjs.Level03Code.condition2IsTrue_0 = {val:false};
gdjs.Level03Code.condition3IsTrue_0 = {val:false};
gdjs.Level03Code.condition4IsTrue_0 = {val:false};
gdjs.Level03Code.conditionTrue_1 = {val:false};
gdjs.Level03Code.condition0IsTrue_1 = {val:false};
gdjs.Level03Code.condition1IsTrue_1 = {val:false};
gdjs.Level03Code.condition2IsTrue_1 = {val:false};
gdjs.Level03Code.condition3IsTrue_1 = {val:false};
gdjs.Level03Code.condition4IsTrue_1 = {val:false};


gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEndObjects1Objects = Hashtable.newFrom({"End": gdjs.Level03Code.GDEndObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRestartObjects2Objects = Hashtable.newFrom({"Restart": gdjs.Level03Code.GDRestartObjects2});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects2});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDKidneyStoneSpikesObjects2Objects = Hashtable.newFrom({"KidneyStoneSpikes": gdjs.Level03Code.GDKidneyStoneSpikesObjects2});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects2});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects = Hashtable.newFrom({"RightBlock": gdjs.Level03Code.GDRightBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDMovingPlatObjects1Objects = Hashtable.newFrom({"MovingPlat": gdjs.Level03Code.GDMovingPlatObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects = Hashtable.newFrom({"LeftBlock": gdjs.Level03Code.GDLeftBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDMovingPlatObjects1Objects = Hashtable.newFrom({"MovingPlat": gdjs.Level03Code.GDMovingPlatObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDDownBlockObjects1Objects = Hashtable.newFrom({"DownBlock": gdjs.Level03Code.GDDownBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDElevatorObjects1Objects = Hashtable.newFrom({"Elevator": gdjs.Level03Code.GDElevatorObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDUpBlockObjects1Objects = Hashtable.newFrom({"UpBlock": gdjs.Level03Code.GDUpBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDElevatorObjects1Objects = Hashtable.newFrom({"Elevator": gdjs.Level03Code.GDElevatorObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level03Code.GDEnemyObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level03Code.GDEnemyObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level03Code.GDEnemyObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects = Hashtable.newFrom({"RightBlock": gdjs.Level03Code.GDRightBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level03Code.GDEnemyObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects = Hashtable.newFrom({"LeftBlock": gdjs.Level03Code.GDLeftBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.Level03Code.GDEnemy1Objects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects = Hashtable.newFrom({"LeftBlock": gdjs.Level03Code.GDLeftBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.Level03Code.GDEnemy1Objects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects = Hashtable.newFrom({"RightBlock": gdjs.Level03Code.GDRightBlockObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.Level03Code.GDEnemy1Objects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.Level03Code.GDEnemy1Objects1});gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level03Code.GDPlayerObjects1});gdjs.Level03Code.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("End"), gdjs.Level03Code.GDEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEndObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Info03", false);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End", true);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level03Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level03Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) < 90;
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, 90, "", 0);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) > 272;
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, 272, "", 0);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level03Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level03Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) < 240;
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 240, "", 0);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) > 3425;
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 3425, "", 0);
}}

}


{



}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DownBlock"), gdjs.Level03Code.GDDownBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level03Code.GDLeftBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level03Code.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightBlock"), gdjs.Level03Code.GDRightBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpBlock"), gdjs.Level03Code.GDUpBlockObjects1);
{for(var i = 0, len = gdjs.Level03Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDRestartObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].returnVariable(gdjs.Level03Code.GDPlayerObjects1[i].getVariables().get("Health")).setNumber(100);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "243;112;181");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Music\\Level03.wav", true, 100, 1);
}{for(var i = 0, len = gdjs.Level03Code.GDLeftBlockObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDLeftBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level03Code.GDRightBlockObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDRightBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level03Code.GDUpBlockObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDUpBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level03Code.GDDownBlockObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDDownBlockObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level03Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level03Code.GDPlayerObjects1[0].getPointY("")) - 160, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level03Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level03Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "stepping.wav", 1, true, 100, 1);
}{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}}

}


{



}


{

gdjs.Level03Code.GDKidneyStoneSpikesObjects1.length = 0;

gdjs.Level03Code.GDPlayerObjects1.length = 0;

gdjs.Level03Code.GDRestartObjects1.length = 0;


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.GDKidneyStoneSpikesObjects1_1final.length = 0;gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.GDRestartObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level03Code.GDRestartObjects2);
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRestartObjects2Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Level03Code.GDRestartObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDRestartObjects1_1final.indexOf(gdjs.Level03Code.GDRestartObjects2[j]) === -1 )
            gdjs.Level03Code.GDRestartObjects1_1final.push(gdjs.Level03Code.GDRestartObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("KidneyStoneSpikes"), gdjs.Level03Code.GDKidneyStoneSpikesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDKidneyStoneSpikesObjects2Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects2Objects, false, runtimeScene, false);
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDKidneyStoneSpikesObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDKidneyStoneSpikesObjects1_1final.indexOf(gdjs.Level03Code.GDKidneyStoneSpikesObjects2[j]) === -1 )
            gdjs.Level03Code.GDKidneyStoneSpikesObjects1_1final.push(gdjs.Level03Code.GDKidneyStoneSpikesObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDKidneyStoneSpikesObjects1_1final, gdjs.Level03Code.GDKidneyStoneSpikesObjects1);
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
gdjs.copyArray(gdjs.Level03Code.GDRestartObjects1_1final, gdjs.Level03Code.GDRestartObjects1);
}
}
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level03", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "squish.wav", false, 100, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.Level03Code.GDLivesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level03Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level03Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level03Code.GDLivesObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDLivesObjects1[i].setString("Lives: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("MovingPlat"), gdjs.Level03Code.GDMovingPlatObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightBlock"), gdjs.Level03Code.GDRightBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDMovingPlatObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDMovingPlatObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDMovingPlatObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDMovingPlatObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDMovingPlatObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDMovingPlatObjects1[i].addForce(-(100), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level03Code.GDLeftBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlat"), gdjs.Level03Code.GDMovingPlatObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDMovingPlatObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDMovingPlatObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDMovingPlatObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDMovingPlatObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDMovingPlatObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDMovingPlatObjects1[i].addForce(100, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DownBlock"), gdjs.Level03Code.GDDownBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Elevator"), gdjs.Level03Code.GDElevatorObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDDownBlockObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDElevatorObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDElevatorObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDElevatorObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDElevatorObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDElevatorObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDElevatorObjects1[i].addForce(0, -(100), 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Elevator"), gdjs.Level03Code.GDElevatorObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpBlock"), gdjs.Level03Code.GDUpBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDUpBlockObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDElevatorObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDElevatorObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDElevatorObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDElevatorObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDElevatorObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDElevatorObjects1[i].addForce(0, 100, 1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level03Code.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
gdjs.Level03Code.condition2IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemyObjects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition2IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemyObjects1[k] = gdjs.Level03Code.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemyObjects1.length = k;}}
}
if (gdjs.Level03Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].setAnimation(gdjs.Level03Code.GDEnemyObjects1[i].getAnimation() + (2));
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].playAnimation();
}
}{runtimeScene.getVariables().getFromIndex(0).add(10);
}{gdjs.evtTools.sound.playSound(runtimeScene, "squish.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level03Code.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemyObjects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemyObjects1[k] = gdjs.Level03Code.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemyObjects1.length = k;}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level03", true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "hit.wav", false, 100, 1.4);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level03Code.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightBlock"), gdjs.Level03Code.GDRightBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemyObjects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemyObjects1[k] = gdjs.Level03Code.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemyObjects1.length = k;}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].addForce(-(30), 0, 1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level03Code.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level03Code.GDLeftBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemyObjects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].addForce(30, 0, 1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemyObjects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.Level03Code.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level03Code.GDLeftBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDLeftBlockObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemy1Objects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemy1Objects1[k] = gdjs.Level03Code.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemy1Objects1.length = k;}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemy1Objects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].addForce(80, 0, 1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.Level03Code.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("RightBlock"), gdjs.Level03Code.GDRightBlockObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDRightBlockObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemy1Objects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemy1Objects1[k] = gdjs.Level03Code.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemy1Objects1.length = k;}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemy1Objects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].addForce(-(80), 0, 1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.Level03Code.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
gdjs.Level03Code.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemy1Objects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition0IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemy1Objects1[k] = gdjs.Level03Code.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemy1Objects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition1IsTrue_0.val ) {
{
gdjs.Level03Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.Level03Code.condition2IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDEnemy1Objects1 */
{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].setOpacity(100);
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].setAnimation(gdjs.Level03Code.GDEnemy1Objects1[i].getAnimation() + (2));
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].pauseAnimation();
}
}{runtimeScene.getVariables().getFromIndex(0).add(10);
}{gdjs.evtTools.sound.playSound(runtimeScene, "squish.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.Level03Code.GDEnemy1Objects1[i].addForce(0, 60, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.Level03Code.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
gdjs.Level03Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDEnemy1Objects1Objects, gdjs.Level03Code.mapOfGDgdjs_46Level03Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDEnemy1Objects1[i].getAnimation() < 2 ) {
        gdjs.Level03Code.condition1IsTrue_0.val = true;
        gdjs.Level03Code.GDEnemy1Objects1[k] = gdjs.Level03Code.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDEnemy1Objects1.length = k;}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hit.wav", false, 100, 1.4);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level03", true);
}{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
gdjs.Level03Code.condition2IsTrue_1.val = false;
gdjs.Level03Code.condition3IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition1IsTrue_1.val ) {
{
gdjs.Level03Code.condition2IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
}if ( gdjs.Level03Code.condition2IsTrue_1.val ) {
{
gdjs.Level03Code.condition3IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
}}
}
}
gdjs.Level03Code.conditionTrue_1.val = true && gdjs.Level03Code.condition0IsTrue_1.val && gdjs.Level03Code.condition1IsTrue_1.val && gdjs.Level03Code.condition2IsTrue_1.val && gdjs.Level03Code.condition3IsTrue_1.val;
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1, gdjs.Level03Code.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 4 ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1, gdjs.Level03Code.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 2 ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
gdjs.Level03Code.condition2IsTrue_1.val = false;
gdjs.Level03Code.condition3IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition1IsTrue_1.val ) {
{
gdjs.Level03Code.condition2IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
}if ( gdjs.Level03Code.condition2IsTrue_1.val ) {
{
gdjs.Level03Code.condition3IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
}}
}
}
gdjs.Level03Code.conditionTrue_1.val = true && gdjs.Level03Code.condition0IsTrue_1.val && gdjs.Level03Code.condition1IsTrue_1.val && gdjs.Level03Code.condition2IsTrue_1.val && gdjs.Level03Code.condition3IsTrue_1.val;
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1, gdjs.Level03Code.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 5 ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1, gdjs.Level03Code.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 3 ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}}
gdjs.Level03Code.conditionTrue_1.val = true && gdjs.Level03Code.condition0IsTrue_1.val && gdjs.Level03Code.condition1IsTrue_1.val;
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{gdjs.evtTools.sound.continueSoundOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}}
gdjs.Level03Code.conditionTrue_1.val = true && gdjs.Level03Code.condition0IsTrue_1.val && gdjs.Level03Code.condition1IsTrue_1.val;
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{gdjs.evtTools.sound.continueSoundOnChannel(runtimeScene, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects1);

gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Level03Code.condition0IsTrue_0.val = true;
        gdjs.Level03Code.GDPlayerObjects1[k] = gdjs.Level03Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects1.length = k;}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13562036);
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Assets\\Music\\jump_07.wav", false, 100, 1);
}}

}


{


gdjs.Level03Code.condition0IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
gdjs.Level03Code.condition2IsTrue_1.val = false;
gdjs.Level03Code.condition3IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition2IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if( gdjs.Level03Code.condition2IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition3IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
if( gdjs.Level03Code.condition3IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}}

}


{



}


{

gdjs.Level03Code.GDPlayerObjects1.length = 0;


gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
gdjs.Level03Code.condition2IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition2IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.Level03Code.condition2IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 0 ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 2 ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(4);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}}

}


{

gdjs.Level03Code.GDPlayerObjects1.length = 0;


gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
gdjs.Level03Code.condition2IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition2IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.Level03Code.condition2IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 1 ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getAnimation() == 3 ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].setAnimation(5);
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.pauseSoundOnChannel(runtimeScene, 1);
}}

}


{

gdjs.Level03Code.GDPlayerObjects1.length = 0;


gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.Level03Code.GDPlayerObjects1.length = 0;


gdjs.Level03Code.condition0IsTrue_0.val = false;
gdjs.Level03Code.condition1IsTrue_0.val = false;
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition0IsTrue_0;
gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.Level03Code.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level03Code.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.Level03Code.condition0IsTrue_0.val ) {
{
{gdjs.Level03Code.conditionTrue_1 = gdjs.Level03Code.condition1IsTrue_0;
gdjs.Level03Code.GDPlayerObjects1_1final.length = 0;gdjs.Level03Code.condition0IsTrue_1.val = false;
gdjs.Level03Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level03Code.condition0IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition0IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level03Code.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.Level03Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level03Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Level03Code.condition1IsTrue_1.val = true;
        gdjs.Level03Code.GDPlayerObjects2[k] = gdjs.Level03Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level03Code.GDPlayerObjects2.length = k;if( gdjs.Level03Code.condition1IsTrue_1.val ) {
    gdjs.Level03Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level03Code.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level03Code.GDPlayerObjects1_1final.indexOf(gdjs.Level03Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level03Code.GDPlayerObjects1_1final.push(gdjs.Level03Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level03Code.GDPlayerObjects1_1final, gdjs.Level03Code.GDPlayerObjects1);
}
}
}}
if (gdjs.Level03Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level03Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level03Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level03Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


};

gdjs.Level03Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level03Code.GDFloorTileObjects1.length = 0;
gdjs.Level03Code.GDFloorTileObjects2.length = 0;
gdjs.Level03Code.GDCliffRightObjects1.length = 0;
gdjs.Level03Code.GDCliffRightObjects2.length = 0;
gdjs.Level03Code.GDWallRightObjects1.length = 0;
gdjs.Level03Code.GDWallRightObjects2.length = 0;
gdjs.Level03Code.GDCliffLeftObjects1.length = 0;
gdjs.Level03Code.GDCliffLeftObjects2.length = 0;
gdjs.Level03Code.GDWallLeftObjects1.length = 0;
gdjs.Level03Code.GDWallLeftObjects2.length = 0;
gdjs.Level03Code.GDCeilLeftObjects1.length = 0;
gdjs.Level03Code.GDCeilLeftObjects2.length = 0;
gdjs.Level03Code.GDCeilTileObjects1.length = 0;
gdjs.Level03Code.GDCeilTileObjects2.length = 0;
gdjs.Level03Code.GDCeilRightObjects1.length = 0;
gdjs.Level03Code.GDCeilRightObjects2.length = 0;
gdjs.Level03Code.GDCornerBRObjects1.length = 0;
gdjs.Level03Code.GDCornerBRObjects2.length = 0;
gdjs.Level03Code.GDCornerBLObjects1.length = 0;
gdjs.Level03Code.GDCornerBLObjects2.length = 0;
gdjs.Level03Code.GDCornerTLObjects1.length = 0;
gdjs.Level03Code.GDCornerTLObjects2.length = 0;
gdjs.Level03Code.GDCornerTRObjects1.length = 0;
gdjs.Level03Code.GDCornerTRObjects2.length = 0;
gdjs.Level03Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Level03Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Level03Code.GDHoverTileRObjects1.length = 0;
gdjs.Level03Code.GDHoverTileRObjects2.length = 0;
gdjs.Level03Code.GDHoverTileLObjects1.length = 0;
gdjs.Level03Code.GDHoverTileLObjects2.length = 0;
gdjs.Level03Code.GDTileObjects1.length = 0;
gdjs.Level03Code.GDTileObjects2.length = 0;
gdjs.Level03Code.GDBGTileObjects1.length = 0;
gdjs.Level03Code.GDBGTileObjects2.length = 0;
gdjs.Level03Code.GDPlayerObjects1.length = 0;
gdjs.Level03Code.GDPlayerObjects2.length = 0;
gdjs.Level03Code.GDTileBaseObjects1.length = 0;
gdjs.Level03Code.GDTileBaseObjects2.length = 0;
gdjs.Level03Code.GDEndObjects1.length = 0;
gdjs.Level03Code.GDEndObjects2.length = 0;
gdjs.Level03Code.GDRestartObjects1.length = 0;
gdjs.Level03Code.GDRestartObjects2.length = 0;
gdjs.Level03Code.GDWallObjects1.length = 0;
gdjs.Level03Code.GDWallObjects2.length = 0;
gdjs.Level03Code.GDLabelObjects1.length = 0;
gdjs.Level03Code.GDLabelObjects2.length = 0;
gdjs.Level03Code.GDElevatorObjects1.length = 0;
gdjs.Level03Code.GDElevatorObjects2.length = 0;
gdjs.Level03Code.GDMovingPlatObjects1.length = 0;
gdjs.Level03Code.GDMovingPlatObjects2.length = 0;
gdjs.Level03Code.GDEnemyObjects1.length = 0;
gdjs.Level03Code.GDEnemyObjects2.length = 0;
gdjs.Level03Code.GDLeftBlockObjects1.length = 0;
gdjs.Level03Code.GDLeftBlockObjects2.length = 0;
gdjs.Level03Code.GDRightBlockObjects1.length = 0;
gdjs.Level03Code.GDRightBlockObjects2.length = 0;
gdjs.Level03Code.GDUpBlockObjects1.length = 0;
gdjs.Level03Code.GDUpBlockObjects2.length = 0;
gdjs.Level03Code.GDDownBlockObjects1.length = 0;
gdjs.Level03Code.GDDownBlockObjects2.length = 0;
gdjs.Level03Code.GDScoreObjects1.length = 0;
gdjs.Level03Code.GDScoreObjects2.length = 0;
gdjs.Level03Code.GDLivesObjects1.length = 0;
gdjs.Level03Code.GDLivesObjects2.length = 0;
gdjs.Level03Code.GDKidneyStoneSpikesObjects1.length = 0;
gdjs.Level03Code.GDKidneyStoneSpikesObjects2.length = 0;
gdjs.Level03Code.GDEnemy1Objects1.length = 0;
gdjs.Level03Code.GDEnemy1Objects2.length = 0;

gdjs.Level03Code.eventsList0(runtimeScene);
return;

}

gdjs['Level03Code'] = gdjs.Level03Code;
