gdjs.Info03Code = {};
gdjs.Info03Code.GDFloorTileObjects1= [];
gdjs.Info03Code.GDFloorTileObjects2= [];
gdjs.Info03Code.GDCliffRightObjects1= [];
gdjs.Info03Code.GDCliffRightObjects2= [];
gdjs.Info03Code.GDWallRightObjects1= [];
gdjs.Info03Code.GDWallRightObjects2= [];
gdjs.Info03Code.GDCliffLeftObjects1= [];
gdjs.Info03Code.GDCliffLeftObjects2= [];
gdjs.Info03Code.GDWallLeftObjects1= [];
gdjs.Info03Code.GDWallLeftObjects2= [];
gdjs.Info03Code.GDCeilLeftObjects1= [];
gdjs.Info03Code.GDCeilLeftObjects2= [];
gdjs.Info03Code.GDCeilTileObjects1= [];
gdjs.Info03Code.GDCeilTileObjects2= [];
gdjs.Info03Code.GDCeilRightObjects1= [];
gdjs.Info03Code.GDCeilRightObjects2= [];
gdjs.Info03Code.GDCornerBRObjects1= [];
gdjs.Info03Code.GDCornerBRObjects2= [];
gdjs.Info03Code.GDCornerBLObjects1= [];
gdjs.Info03Code.GDCornerBLObjects2= [];
gdjs.Info03Code.GDCornerTLObjects1= [];
gdjs.Info03Code.GDCornerTLObjects2= [];
gdjs.Info03Code.GDCornerTRObjects1= [];
gdjs.Info03Code.GDCornerTRObjects2= [];
gdjs.Info03Code.GDHoverTileHorizontalObjects1= [];
gdjs.Info03Code.GDHoverTileHorizontalObjects2= [];
gdjs.Info03Code.GDHoverTileRObjects1= [];
gdjs.Info03Code.GDHoverTileRObjects2= [];
gdjs.Info03Code.GDHoverTileLObjects1= [];
gdjs.Info03Code.GDHoverTileLObjects2= [];
gdjs.Info03Code.GDTileObjects1= [];
gdjs.Info03Code.GDTileObjects2= [];
gdjs.Info03Code.GDBGTileObjects1= [];
gdjs.Info03Code.GDBGTileObjects2= [];
gdjs.Info03Code.GDDescObjects1= [];
gdjs.Info03Code.GDDescObjects2= [];
gdjs.Info03Code.GDNewObjectObjects1= [];
gdjs.Info03Code.GDNewObjectObjects2= [];

gdjs.Info03Code.conditionTrue_0 = {val:false};
gdjs.Info03Code.condition0IsTrue_0 = {val:false};
gdjs.Info03Code.condition1IsTrue_0 = {val:false};
gdjs.Info03Code.condition2IsTrue_0 = {val:false};


gdjs.Info03Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.Info03Code.GDDescObjects1);
{for(var i = 0, len = gdjs.Info03Code.GDDescObjects1.length ;i < len;++i) {
    gdjs.Info03Code.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.Info03Code.condition0IsTrue_0.val = false;
{
gdjs.Info03Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.Info03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level04", false);
}}

}


{


gdjs.Info03Code.condition0IsTrue_0.val = false;
{
gdjs.Info03Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Info03Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Info03Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Info03Code.GDFloorTileObjects1.length = 0;
gdjs.Info03Code.GDFloorTileObjects2.length = 0;
gdjs.Info03Code.GDCliffRightObjects1.length = 0;
gdjs.Info03Code.GDCliffRightObjects2.length = 0;
gdjs.Info03Code.GDWallRightObjects1.length = 0;
gdjs.Info03Code.GDWallRightObjects2.length = 0;
gdjs.Info03Code.GDCliffLeftObjects1.length = 0;
gdjs.Info03Code.GDCliffLeftObjects2.length = 0;
gdjs.Info03Code.GDWallLeftObjects1.length = 0;
gdjs.Info03Code.GDWallLeftObjects2.length = 0;
gdjs.Info03Code.GDCeilLeftObjects1.length = 0;
gdjs.Info03Code.GDCeilLeftObjects2.length = 0;
gdjs.Info03Code.GDCeilTileObjects1.length = 0;
gdjs.Info03Code.GDCeilTileObjects2.length = 0;
gdjs.Info03Code.GDCeilRightObjects1.length = 0;
gdjs.Info03Code.GDCeilRightObjects2.length = 0;
gdjs.Info03Code.GDCornerBRObjects1.length = 0;
gdjs.Info03Code.GDCornerBRObjects2.length = 0;
gdjs.Info03Code.GDCornerBLObjects1.length = 0;
gdjs.Info03Code.GDCornerBLObjects2.length = 0;
gdjs.Info03Code.GDCornerTLObjects1.length = 0;
gdjs.Info03Code.GDCornerTLObjects2.length = 0;
gdjs.Info03Code.GDCornerTRObjects1.length = 0;
gdjs.Info03Code.GDCornerTRObjects2.length = 0;
gdjs.Info03Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Info03Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Info03Code.GDHoverTileRObjects1.length = 0;
gdjs.Info03Code.GDHoverTileRObjects2.length = 0;
gdjs.Info03Code.GDHoverTileLObjects1.length = 0;
gdjs.Info03Code.GDHoverTileLObjects2.length = 0;
gdjs.Info03Code.GDTileObjects1.length = 0;
gdjs.Info03Code.GDTileObjects2.length = 0;
gdjs.Info03Code.GDBGTileObjects1.length = 0;
gdjs.Info03Code.GDBGTileObjects2.length = 0;
gdjs.Info03Code.GDDescObjects1.length = 0;
gdjs.Info03Code.GDDescObjects2.length = 0;
gdjs.Info03Code.GDNewObjectObjects1.length = 0;
gdjs.Info03Code.GDNewObjectObjects2.length = 0;

gdjs.Info03Code.eventsList0(runtimeScene);
return;

}

gdjs['Info03Code'] = gdjs.Info03Code;
