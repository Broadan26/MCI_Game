gdjs.Level05Code = {};
gdjs.Level05Code.GDFloorTileObjects1= [];
gdjs.Level05Code.GDFloorTileObjects2= [];
gdjs.Level05Code.GDCliffRightObjects1= [];
gdjs.Level05Code.GDCliffRightObjects2= [];
gdjs.Level05Code.GDWallRightObjects1= [];
gdjs.Level05Code.GDWallRightObjects2= [];
gdjs.Level05Code.GDCliffLeftObjects1= [];
gdjs.Level05Code.GDCliffLeftObjects2= [];
gdjs.Level05Code.GDWallLeftObjects1= [];
gdjs.Level05Code.GDWallLeftObjects2= [];
gdjs.Level05Code.GDCeilLeftObjects1= [];
gdjs.Level05Code.GDCeilLeftObjects2= [];
gdjs.Level05Code.GDCeilTileObjects1= [];
gdjs.Level05Code.GDCeilTileObjects2= [];
gdjs.Level05Code.GDCeilRightObjects1= [];
gdjs.Level05Code.GDCeilRightObjects2= [];
gdjs.Level05Code.GDCornerBRObjects1= [];
gdjs.Level05Code.GDCornerBRObjects2= [];
gdjs.Level05Code.GDCornerBLObjects1= [];
gdjs.Level05Code.GDCornerBLObjects2= [];
gdjs.Level05Code.GDCornerTLObjects1= [];
gdjs.Level05Code.GDCornerTLObjects2= [];
gdjs.Level05Code.GDCornerTRObjects1= [];
gdjs.Level05Code.GDCornerTRObjects2= [];
gdjs.Level05Code.GDHoverTileHorizontalObjects1= [];
gdjs.Level05Code.GDHoverTileHorizontalObjects2= [];
gdjs.Level05Code.GDHoverTileRObjects1= [];
gdjs.Level05Code.GDHoverTileRObjects2= [];
gdjs.Level05Code.GDHoverTileLObjects1= [];
gdjs.Level05Code.GDHoverTileLObjects2= [];
gdjs.Level05Code.GDTileObjects1= [];
gdjs.Level05Code.GDTileObjects2= [];
gdjs.Level05Code.GDBGTileObjects1= [];
gdjs.Level05Code.GDBGTileObjects2= [];
gdjs.Level05Code.GDPlayerObjects1= [];
gdjs.Level05Code.GDPlayerObjects2= [];
gdjs.Level05Code.GDTileBaseTObjects1= [];
gdjs.Level05Code.GDTileBaseTObjects2= [];
gdjs.Level05Code.GDTileBaseBObjects1= [];
gdjs.Level05Code.GDTileBaseBObjects2= [];
gdjs.Level05Code.GDLabelObjects1= [];
gdjs.Level05Code.GDLabelObjects2= [];
gdjs.Level05Code.GDEndObjects1= [];
gdjs.Level05Code.GDEndObjects2= [];
gdjs.Level05Code.GDWallObjects1= [];
gdjs.Level05Code.GDWallObjects2= [];
gdjs.Level05Code.GDElevatorObjects1= [];
gdjs.Level05Code.GDElevatorObjects2= [];
gdjs.Level05Code.GDMovingPlatObjects1= [];
gdjs.Level05Code.GDMovingPlatObjects2= [];
gdjs.Level05Code.GDEnemyObjects1= [];
gdjs.Level05Code.GDEnemyObjects2= [];
gdjs.Level05Code.GDLeftBlockObjects1= [];
gdjs.Level05Code.GDLeftBlockObjects2= [];
gdjs.Level05Code.GDRightBlockObjects1= [];
gdjs.Level05Code.GDRightBlockObjects2= [];
gdjs.Level05Code.GDUpBlockObjects1= [];
gdjs.Level05Code.GDUpBlockObjects2= [];
gdjs.Level05Code.GDDownBlockObjects1= [];
gdjs.Level05Code.GDDownBlockObjects2= [];
gdjs.Level05Code.GDScoreObjects1= [];
gdjs.Level05Code.GDScoreObjects2= [];
gdjs.Level05Code.GDLivesObjects1= [];
gdjs.Level05Code.GDLivesObjects2= [];
gdjs.Level05Code.GDKidneyStoneRollObjects1= [];
gdjs.Level05Code.GDKidneyStoneRollObjects2= [];
gdjs.Level05Code.GDBG2Objects1= [];
gdjs.Level05Code.GDBG2Objects2= [];

gdjs.Level05Code.conditionTrue_0 = {val:false};
gdjs.Level05Code.condition0IsTrue_0 = {val:false};
gdjs.Level05Code.condition1IsTrue_0 = {val:false};
gdjs.Level05Code.condition2IsTrue_0 = {val:false};
gdjs.Level05Code.conditionTrue_1 = {val:false};
gdjs.Level05Code.condition0IsTrue_1 = {val:false};
gdjs.Level05Code.condition1IsTrue_1 = {val:false};
gdjs.Level05Code.condition2IsTrue_1 = {val:false};
gdjs.Level05Code.conditionTrue_2 = {val:false};
gdjs.Level05Code.condition0IsTrue_2 = {val:false};
gdjs.Level05Code.condition1IsTrue_2 = {val:false};
gdjs.Level05Code.condition2IsTrue_2 = {val:false};


gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDEndObjects1Objects = Hashtable.newFrom({"End": gdjs.Level05Code.GDEndObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDKidneyStoneRollObjects1Objects = Hashtable.newFrom({"KidneyStoneRoll": gdjs.Level05Code.GDKidneyStoneRollObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDKidneyStoneRollObjects1Objects = Hashtable.newFrom({"KidneyStoneRoll": gdjs.Level05Code.GDKidneyStoneRollObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDLeftBlockObjects1Objects = Hashtable.newFrom({"LeftBlock": gdjs.Level05Code.GDLeftBlockObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level05Code.GDEnemyObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseTObjects1Objects = Hashtable.newFrom({"TileBaseT": gdjs.Level05Code.GDTileBaseTObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseBObjects1Objects = Hashtable.newFrom({"TileBaseB": gdjs.Level05Code.GDTileBaseBObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseTObjects1Objects = Hashtable.newFrom({"TileBaseT": gdjs.Level05Code.GDTileBaseTObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level05Code.GDPlayerObjects1});gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseBObjects1Objects = Hashtable.newFrom({"TileBaseB": gdjs.Level05Code.GDTileBaseBObjects1});gdjs.Level05Code.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DownBlock"), gdjs.Level05Code.GDDownBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("End"), gdjs.Level05Code.GDEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level05Code.GDLeftBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightBlock"), gdjs.Level05Code.GDRightBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpBlock"), gdjs.Level05Code.GDUpBlockObjects1);
{for(var i = 0, len = gdjs.Level05Code.GDEndObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDEndObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].returnVariable(gdjs.Level05Code.GDPlayerObjects1[i].getVariables().get("Health")).setNumber(100);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "243;112;181");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Music\\Level05.wav", true, 100, 1);
}{for(var i = 0, len = gdjs.Level05Code.GDLeftBlockObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDLeftBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level05Code.GDRightBlockObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDRightBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level05Code.GDUpBlockObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDUpBlockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level05Code.GDDownBlockObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDDownBlockObjects1[i].hide();
}
}{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level05Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level05Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level05Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level05Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].addForce(300, 0, 1);
}
}}

}


{



}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("End"), gdjs.Level05Code.GDEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDEndObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Congrats", false);
}}

}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End", true);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level05Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level05Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) < 240;
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, 240, "", 0);
}}

}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) > 260;
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, 260, "", 0);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level05Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level05Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) < 220;
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 220, "", 0);
}}

}


{


gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) > 4700;
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 4700, "", 0);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.Level05Code.GDLivesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level05Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level05Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Level05Code.GDLivesObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDLivesObjects1[i].setString("Lives: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("KidneyStoneRoll"), gdjs.Level05Code.GDKidneyStoneRollObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDKidneyStoneRollObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level05", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("KidneyStoneRoll"), gdjs.Level05Code.GDKidneyStoneRollObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBlock"), gdjs.Level05Code.GDLeftBlockObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDKidneyStoneRollObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDLeftBlockObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level05Code.GDKidneyStoneRollObjects1 */
{for(var i = 0, len = gdjs.Level05Code.GDKidneyStoneRollObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDKidneyStoneRollObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level05Code.GDKidneyStoneRollObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDKidneyStoneRollObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.Level05Code.GDKidneyStoneRollObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDKidneyStoneRollObjects1[i].addForce(150, 0, 1);
}
}{for(var i = 0, len = gdjs.Level05Code.GDKidneyStoneRollObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDKidneyStoneRollObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level05Code.GDKidneyStoneRollObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDKidneyStoneRollObjects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level05Code.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDEnemyObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "hit.wav", false, 100, 1.4);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level05", true);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("TileBaseT"), gdjs.Level05Code.GDTileBaseTObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseTObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level05Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].addForce(300, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("TileBaseB"), gdjs.Level05Code.GDTileBaseBObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
gdjs.Level05Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseBObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level05Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].addForce(300, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("TileBaseT"), gdjs.Level05Code.GDTileBaseTObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
{gdjs.Level05Code.conditionTrue_1 = gdjs.Level05Code.condition0IsTrue_0;
gdjs.Level05Code.condition0IsTrue_1.val = false;
gdjs.Level05Code.condition1IsTrue_1.val = false;
{
{gdjs.Level05Code.conditionTrue_2 = gdjs.Level05Code.condition0IsTrue_1;
gdjs.Level05Code.condition0IsTrue_2.val = false;
gdjs.Level05Code.condition1IsTrue_2.val = false;
{
gdjs.Level05Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.Level05Code.condition0IsTrue_2.val ) {
    gdjs.Level05Code.conditionTrue_2.val = true;
}
}
{
gdjs.Level05Code.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.Level05Code.condition1IsTrue_2.val ) {
    gdjs.Level05Code.conditionTrue_2.val = true;
}
}
{
}
}
}if ( gdjs.Level05Code.condition0IsTrue_1.val ) {
{
gdjs.Level05Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseTObjects1Objects, true, runtimeScene, false);
}}
gdjs.Level05Code.conditionTrue_1.val = true && gdjs.Level05Code.condition0IsTrue_1.val && gdjs.Level05Code.condition1IsTrue_1.val;
}
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level05Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].addForce(0, -(300), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level05Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("TileBaseB"), gdjs.Level05Code.GDTileBaseBObjects1);

gdjs.Level05Code.condition0IsTrue_0.val = false;
{
{gdjs.Level05Code.conditionTrue_1 = gdjs.Level05Code.condition0IsTrue_0;
gdjs.Level05Code.condition0IsTrue_1.val = false;
gdjs.Level05Code.condition1IsTrue_1.val = false;
{
{gdjs.Level05Code.conditionTrue_2 = gdjs.Level05Code.condition0IsTrue_1;
gdjs.Level05Code.condition0IsTrue_2.val = false;
gdjs.Level05Code.condition1IsTrue_2.val = false;
{
gdjs.Level05Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.Level05Code.condition0IsTrue_2.val ) {
    gdjs.Level05Code.conditionTrue_2.val = true;
}
}
{
gdjs.Level05Code.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if( gdjs.Level05Code.condition1IsTrue_2.val ) {
    gdjs.Level05Code.conditionTrue_2.val = true;
}
}
{
}
}
}if ( gdjs.Level05Code.condition0IsTrue_1.val ) {
{
gdjs.Level05Code.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDPlayerObjects1Objects, gdjs.Level05Code.mapOfGDgdjs_46Level05Code_46GDTileBaseBObjects1Objects, true, runtimeScene, false);
}}
gdjs.Level05Code.conditionTrue_1.val = true && gdjs.Level05Code.condition0IsTrue_1.val && gdjs.Level05Code.condition1IsTrue_1.val;
}
}if (gdjs.Level05Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level05Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level05Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level05Code.GDPlayerObjects1[i].addForce(0, 300, 0);
}
}}

}


};

gdjs.Level05Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level05Code.GDFloorTileObjects1.length = 0;
gdjs.Level05Code.GDFloorTileObjects2.length = 0;
gdjs.Level05Code.GDCliffRightObjects1.length = 0;
gdjs.Level05Code.GDCliffRightObjects2.length = 0;
gdjs.Level05Code.GDWallRightObjects1.length = 0;
gdjs.Level05Code.GDWallRightObjects2.length = 0;
gdjs.Level05Code.GDCliffLeftObjects1.length = 0;
gdjs.Level05Code.GDCliffLeftObjects2.length = 0;
gdjs.Level05Code.GDWallLeftObjects1.length = 0;
gdjs.Level05Code.GDWallLeftObjects2.length = 0;
gdjs.Level05Code.GDCeilLeftObjects1.length = 0;
gdjs.Level05Code.GDCeilLeftObjects2.length = 0;
gdjs.Level05Code.GDCeilTileObjects1.length = 0;
gdjs.Level05Code.GDCeilTileObjects2.length = 0;
gdjs.Level05Code.GDCeilRightObjects1.length = 0;
gdjs.Level05Code.GDCeilRightObjects2.length = 0;
gdjs.Level05Code.GDCornerBRObjects1.length = 0;
gdjs.Level05Code.GDCornerBRObjects2.length = 0;
gdjs.Level05Code.GDCornerBLObjects1.length = 0;
gdjs.Level05Code.GDCornerBLObjects2.length = 0;
gdjs.Level05Code.GDCornerTLObjects1.length = 0;
gdjs.Level05Code.GDCornerTLObjects2.length = 0;
gdjs.Level05Code.GDCornerTRObjects1.length = 0;
gdjs.Level05Code.GDCornerTRObjects2.length = 0;
gdjs.Level05Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Level05Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Level05Code.GDHoverTileRObjects1.length = 0;
gdjs.Level05Code.GDHoverTileRObjects2.length = 0;
gdjs.Level05Code.GDHoverTileLObjects1.length = 0;
gdjs.Level05Code.GDHoverTileLObjects2.length = 0;
gdjs.Level05Code.GDTileObjects1.length = 0;
gdjs.Level05Code.GDTileObjects2.length = 0;
gdjs.Level05Code.GDBGTileObjects1.length = 0;
gdjs.Level05Code.GDBGTileObjects2.length = 0;
gdjs.Level05Code.GDPlayerObjects1.length = 0;
gdjs.Level05Code.GDPlayerObjects2.length = 0;
gdjs.Level05Code.GDTileBaseTObjects1.length = 0;
gdjs.Level05Code.GDTileBaseTObjects2.length = 0;
gdjs.Level05Code.GDTileBaseBObjects1.length = 0;
gdjs.Level05Code.GDTileBaseBObjects2.length = 0;
gdjs.Level05Code.GDLabelObjects1.length = 0;
gdjs.Level05Code.GDLabelObjects2.length = 0;
gdjs.Level05Code.GDEndObjects1.length = 0;
gdjs.Level05Code.GDEndObjects2.length = 0;
gdjs.Level05Code.GDWallObjects1.length = 0;
gdjs.Level05Code.GDWallObjects2.length = 0;
gdjs.Level05Code.GDElevatorObjects1.length = 0;
gdjs.Level05Code.GDElevatorObjects2.length = 0;
gdjs.Level05Code.GDMovingPlatObjects1.length = 0;
gdjs.Level05Code.GDMovingPlatObjects2.length = 0;
gdjs.Level05Code.GDEnemyObjects1.length = 0;
gdjs.Level05Code.GDEnemyObjects2.length = 0;
gdjs.Level05Code.GDLeftBlockObjects1.length = 0;
gdjs.Level05Code.GDLeftBlockObjects2.length = 0;
gdjs.Level05Code.GDRightBlockObjects1.length = 0;
gdjs.Level05Code.GDRightBlockObjects2.length = 0;
gdjs.Level05Code.GDUpBlockObjects1.length = 0;
gdjs.Level05Code.GDUpBlockObjects2.length = 0;
gdjs.Level05Code.GDDownBlockObjects1.length = 0;
gdjs.Level05Code.GDDownBlockObjects2.length = 0;
gdjs.Level05Code.GDScoreObjects1.length = 0;
gdjs.Level05Code.GDScoreObjects2.length = 0;
gdjs.Level05Code.GDLivesObjects1.length = 0;
gdjs.Level05Code.GDLivesObjects2.length = 0;
gdjs.Level05Code.GDKidneyStoneRollObjects1.length = 0;
gdjs.Level05Code.GDKidneyStoneRollObjects2.length = 0;
gdjs.Level05Code.GDBG2Objects1.length = 0;
gdjs.Level05Code.GDBG2Objects2.length = 0;

gdjs.Level05Code.eventsList0(runtimeScene);
return;

}

gdjs['Level05Code'] = gdjs.Level05Code;
