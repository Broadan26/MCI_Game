gdjs.IntroCode = {};
gdjs.IntroCode.GDFloorTileObjects1= [];
gdjs.IntroCode.GDFloorTileObjects2= [];
gdjs.IntroCode.GDCliffRightObjects1= [];
gdjs.IntroCode.GDCliffRightObjects2= [];
gdjs.IntroCode.GDWallRightObjects1= [];
gdjs.IntroCode.GDWallRightObjects2= [];
gdjs.IntroCode.GDCliffLeftObjects1= [];
gdjs.IntroCode.GDCliffLeftObjects2= [];
gdjs.IntroCode.GDWallLeftObjects1= [];
gdjs.IntroCode.GDWallLeftObjects2= [];
gdjs.IntroCode.GDCeilLeftObjects1= [];
gdjs.IntroCode.GDCeilLeftObjects2= [];
gdjs.IntroCode.GDCeilTileObjects1= [];
gdjs.IntroCode.GDCeilTileObjects2= [];
gdjs.IntroCode.GDCeilRightObjects1= [];
gdjs.IntroCode.GDCeilRightObjects2= [];
gdjs.IntroCode.GDCornerBRObjects1= [];
gdjs.IntroCode.GDCornerBRObjects2= [];
gdjs.IntroCode.GDCornerBLObjects1= [];
gdjs.IntroCode.GDCornerBLObjects2= [];
gdjs.IntroCode.GDCornerTLObjects1= [];
gdjs.IntroCode.GDCornerTLObjects2= [];
gdjs.IntroCode.GDCornerTRObjects1= [];
gdjs.IntroCode.GDCornerTRObjects2= [];
gdjs.IntroCode.GDHoverTileHorizontalObjects1= [];
gdjs.IntroCode.GDHoverTileHorizontalObjects2= [];
gdjs.IntroCode.GDHoverTileRObjects1= [];
gdjs.IntroCode.GDHoverTileRObjects2= [];
gdjs.IntroCode.GDHoverTileLObjects1= [];
gdjs.IntroCode.GDHoverTileLObjects2= [];
gdjs.IntroCode.GDTileObjects1= [];
gdjs.IntroCode.GDTileObjects2= [];
gdjs.IntroCode.GDBGTileObjects1= [];
gdjs.IntroCode.GDBGTileObjects2= [];
gdjs.IntroCode.GDDescObjects1= [];
gdjs.IntroCode.GDDescObjects2= [];
gdjs.IntroCode.GDNewObjectObjects1= [];
gdjs.IntroCode.GDNewObjectObjects2= [];

gdjs.IntroCode.conditionTrue_0 = {val:false};
gdjs.IntroCode.condition0IsTrue_0 = {val:false};
gdjs.IntroCode.condition1IsTrue_0 = {val:false};
gdjs.IntroCode.condition2IsTrue_0 = {val:false};


gdjs.IntroCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.IntroCode.GDDescObjects1);
{for(var i = 0, len = gdjs.IntroCode.GDDescObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level01", false);
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.IntroCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.IntroCode.GDFloorTileObjects1.length = 0;
gdjs.IntroCode.GDFloorTileObjects2.length = 0;
gdjs.IntroCode.GDCliffRightObjects1.length = 0;
gdjs.IntroCode.GDCliffRightObjects2.length = 0;
gdjs.IntroCode.GDWallRightObjects1.length = 0;
gdjs.IntroCode.GDWallRightObjects2.length = 0;
gdjs.IntroCode.GDCliffLeftObjects1.length = 0;
gdjs.IntroCode.GDCliffLeftObjects2.length = 0;
gdjs.IntroCode.GDWallLeftObjects1.length = 0;
gdjs.IntroCode.GDWallLeftObjects2.length = 0;
gdjs.IntroCode.GDCeilLeftObjects1.length = 0;
gdjs.IntroCode.GDCeilLeftObjects2.length = 0;
gdjs.IntroCode.GDCeilTileObjects1.length = 0;
gdjs.IntroCode.GDCeilTileObjects2.length = 0;
gdjs.IntroCode.GDCeilRightObjects1.length = 0;
gdjs.IntroCode.GDCeilRightObjects2.length = 0;
gdjs.IntroCode.GDCornerBRObjects1.length = 0;
gdjs.IntroCode.GDCornerBRObjects2.length = 0;
gdjs.IntroCode.GDCornerBLObjects1.length = 0;
gdjs.IntroCode.GDCornerBLObjects2.length = 0;
gdjs.IntroCode.GDCornerTLObjects1.length = 0;
gdjs.IntroCode.GDCornerTLObjects2.length = 0;
gdjs.IntroCode.GDCornerTRObjects1.length = 0;
gdjs.IntroCode.GDCornerTRObjects2.length = 0;
gdjs.IntroCode.GDHoverTileHorizontalObjects1.length = 0;
gdjs.IntroCode.GDHoverTileHorizontalObjects2.length = 0;
gdjs.IntroCode.GDHoverTileRObjects1.length = 0;
gdjs.IntroCode.GDHoverTileRObjects2.length = 0;
gdjs.IntroCode.GDHoverTileLObjects1.length = 0;
gdjs.IntroCode.GDHoverTileLObjects2.length = 0;
gdjs.IntroCode.GDTileObjects1.length = 0;
gdjs.IntroCode.GDTileObjects2.length = 0;
gdjs.IntroCode.GDBGTileObjects1.length = 0;
gdjs.IntroCode.GDBGTileObjects2.length = 0;
gdjs.IntroCode.GDDescObjects1.length = 0;
gdjs.IntroCode.GDDescObjects2.length = 0;
gdjs.IntroCode.GDNewObjectObjects1.length = 0;
gdjs.IntroCode.GDNewObjectObjects2.length = 0;

gdjs.IntroCode.eventsList0(runtimeScene);
return;

}

gdjs['IntroCode'] = gdjs.IntroCode;
