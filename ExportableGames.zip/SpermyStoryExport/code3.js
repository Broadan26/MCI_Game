gdjs.Info01Code = {};
gdjs.Info01Code.GDFloorTileObjects1= [];
gdjs.Info01Code.GDFloorTileObjects2= [];
gdjs.Info01Code.GDCliffRightObjects1= [];
gdjs.Info01Code.GDCliffRightObjects2= [];
gdjs.Info01Code.GDWallRightObjects1= [];
gdjs.Info01Code.GDWallRightObjects2= [];
gdjs.Info01Code.GDCliffLeftObjects1= [];
gdjs.Info01Code.GDCliffLeftObjects2= [];
gdjs.Info01Code.GDWallLeftObjects1= [];
gdjs.Info01Code.GDWallLeftObjects2= [];
gdjs.Info01Code.GDCeilLeftObjects1= [];
gdjs.Info01Code.GDCeilLeftObjects2= [];
gdjs.Info01Code.GDCeilTileObjects1= [];
gdjs.Info01Code.GDCeilTileObjects2= [];
gdjs.Info01Code.GDCeilRightObjects1= [];
gdjs.Info01Code.GDCeilRightObjects2= [];
gdjs.Info01Code.GDCornerBRObjects1= [];
gdjs.Info01Code.GDCornerBRObjects2= [];
gdjs.Info01Code.GDCornerBLObjects1= [];
gdjs.Info01Code.GDCornerBLObjects2= [];
gdjs.Info01Code.GDCornerTLObjects1= [];
gdjs.Info01Code.GDCornerTLObjects2= [];
gdjs.Info01Code.GDCornerTRObjects1= [];
gdjs.Info01Code.GDCornerTRObjects2= [];
gdjs.Info01Code.GDHoverTileHorizontalObjects1= [];
gdjs.Info01Code.GDHoverTileHorizontalObjects2= [];
gdjs.Info01Code.GDHoverTileRObjects1= [];
gdjs.Info01Code.GDHoverTileRObjects2= [];
gdjs.Info01Code.GDHoverTileLObjects1= [];
gdjs.Info01Code.GDHoverTileLObjects2= [];
gdjs.Info01Code.GDTileObjects1= [];
gdjs.Info01Code.GDTileObjects2= [];
gdjs.Info01Code.GDBGTileObjects1= [];
gdjs.Info01Code.GDBGTileObjects2= [];
gdjs.Info01Code.GDDescObjects1= [];
gdjs.Info01Code.GDDescObjects2= [];
gdjs.Info01Code.GDNewObjectObjects1= [];
gdjs.Info01Code.GDNewObjectObjects2= [];

gdjs.Info01Code.conditionTrue_0 = {val:false};
gdjs.Info01Code.condition0IsTrue_0 = {val:false};
gdjs.Info01Code.condition1IsTrue_0 = {val:false};
gdjs.Info01Code.condition2IsTrue_0 = {val:false};


gdjs.Info01Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.Info01Code.GDDescObjects1);
{for(var i = 0, len = gdjs.Info01Code.GDDescObjects1.length ;i < len;++i) {
    gdjs.Info01Code.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.Info01Code.condition0IsTrue_0.val = false;
{
gdjs.Info01Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.Info01Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level02", false);
}}

}


{


gdjs.Info01Code.condition0IsTrue_0.val = false;
{
gdjs.Info01Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Info01Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Info01Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Info01Code.GDFloorTileObjects1.length = 0;
gdjs.Info01Code.GDFloorTileObjects2.length = 0;
gdjs.Info01Code.GDCliffRightObjects1.length = 0;
gdjs.Info01Code.GDCliffRightObjects2.length = 0;
gdjs.Info01Code.GDWallRightObjects1.length = 0;
gdjs.Info01Code.GDWallRightObjects2.length = 0;
gdjs.Info01Code.GDCliffLeftObjects1.length = 0;
gdjs.Info01Code.GDCliffLeftObjects2.length = 0;
gdjs.Info01Code.GDWallLeftObjects1.length = 0;
gdjs.Info01Code.GDWallLeftObjects2.length = 0;
gdjs.Info01Code.GDCeilLeftObjects1.length = 0;
gdjs.Info01Code.GDCeilLeftObjects2.length = 0;
gdjs.Info01Code.GDCeilTileObjects1.length = 0;
gdjs.Info01Code.GDCeilTileObjects2.length = 0;
gdjs.Info01Code.GDCeilRightObjects1.length = 0;
gdjs.Info01Code.GDCeilRightObjects2.length = 0;
gdjs.Info01Code.GDCornerBRObjects1.length = 0;
gdjs.Info01Code.GDCornerBRObjects2.length = 0;
gdjs.Info01Code.GDCornerBLObjects1.length = 0;
gdjs.Info01Code.GDCornerBLObjects2.length = 0;
gdjs.Info01Code.GDCornerTLObjects1.length = 0;
gdjs.Info01Code.GDCornerTLObjects2.length = 0;
gdjs.Info01Code.GDCornerTRObjects1.length = 0;
gdjs.Info01Code.GDCornerTRObjects2.length = 0;
gdjs.Info01Code.GDHoverTileHorizontalObjects1.length = 0;
gdjs.Info01Code.GDHoverTileHorizontalObjects2.length = 0;
gdjs.Info01Code.GDHoverTileRObjects1.length = 0;
gdjs.Info01Code.GDHoverTileRObjects2.length = 0;
gdjs.Info01Code.GDHoverTileLObjects1.length = 0;
gdjs.Info01Code.GDHoverTileLObjects2.length = 0;
gdjs.Info01Code.GDTileObjects1.length = 0;
gdjs.Info01Code.GDTileObjects2.length = 0;
gdjs.Info01Code.GDBGTileObjects1.length = 0;
gdjs.Info01Code.GDBGTileObjects2.length = 0;
gdjs.Info01Code.GDDescObjects1.length = 0;
gdjs.Info01Code.GDDescObjects2.length = 0;
gdjs.Info01Code.GDNewObjectObjects1.length = 0;
gdjs.Info01Code.GDNewObjectObjects2.length = 0;

gdjs.Info01Code.eventsList0(runtimeScene);
return;

}

gdjs['Info01Code'] = gdjs.Info01Code;
