gdjs.EndCode = {};
gdjs.EndCode.GDFloorTileObjects1= [];
gdjs.EndCode.GDFloorTileObjects2= [];
gdjs.EndCode.GDCliffRightObjects1= [];
gdjs.EndCode.GDCliffRightObjects2= [];
gdjs.EndCode.GDWallRightObjects1= [];
gdjs.EndCode.GDWallRightObjects2= [];
gdjs.EndCode.GDCliffLeftObjects1= [];
gdjs.EndCode.GDCliffLeftObjects2= [];
gdjs.EndCode.GDWallLeftObjects1= [];
gdjs.EndCode.GDWallLeftObjects2= [];
gdjs.EndCode.GDCeilLeftObjects1= [];
gdjs.EndCode.GDCeilLeftObjects2= [];
gdjs.EndCode.GDCeilTileObjects1= [];
gdjs.EndCode.GDCeilTileObjects2= [];
gdjs.EndCode.GDCeilRightObjects1= [];
gdjs.EndCode.GDCeilRightObjects2= [];
gdjs.EndCode.GDCornerBRObjects1= [];
gdjs.EndCode.GDCornerBRObjects2= [];
gdjs.EndCode.GDCornerBLObjects1= [];
gdjs.EndCode.GDCornerBLObjects2= [];
gdjs.EndCode.GDCornerTLObjects1= [];
gdjs.EndCode.GDCornerTLObjects2= [];
gdjs.EndCode.GDCornerTRObjects1= [];
gdjs.EndCode.GDCornerTRObjects2= [];
gdjs.EndCode.GDHoverTileHorizontalObjects1= [];
gdjs.EndCode.GDHoverTileHorizontalObjects2= [];
gdjs.EndCode.GDHoverTileRObjects1= [];
gdjs.EndCode.GDHoverTileRObjects2= [];
gdjs.EndCode.GDHoverTileLObjects1= [];
gdjs.EndCode.GDHoverTileLObjects2= [];
gdjs.EndCode.GDTileObjects1= [];
gdjs.EndCode.GDTileObjects2= [];
gdjs.EndCode.GDBGTileObjects1= [];
gdjs.EndCode.GDBGTileObjects2= [];
gdjs.EndCode.GDCreditsObjects1= [];
gdjs.EndCode.GDCreditsObjects2= [];
gdjs.EndCode.GDNewObjectObjects1= [];
gdjs.EndCode.GDNewObjectObjects2= [];

gdjs.EndCode.conditionTrue_0 = {val:false};
gdjs.EndCode.condition0IsTrue_0 = {val:false};
gdjs.EndCode.condition1IsTrue_0 = {val:false};


gdjs.EndCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Credits"), gdjs.EndCode.GDCreditsObjects1);
{for(var i = 0, len = gdjs.EndCode.GDCreditsObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDCreditsObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.EndCode.condition0IsTrue_0.val = false;
{
gdjs.EndCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.EndCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


gdjs.EndCode.condition0IsTrue_0.val = false;
{
gdjs.EndCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.EndCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Music\\MainMenuSong.wav", true, 100, 1);
}}

}


};

gdjs.EndCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndCode.GDFloorTileObjects1.length = 0;
gdjs.EndCode.GDFloorTileObjects2.length = 0;
gdjs.EndCode.GDCliffRightObjects1.length = 0;
gdjs.EndCode.GDCliffRightObjects2.length = 0;
gdjs.EndCode.GDWallRightObjects1.length = 0;
gdjs.EndCode.GDWallRightObjects2.length = 0;
gdjs.EndCode.GDCliffLeftObjects1.length = 0;
gdjs.EndCode.GDCliffLeftObjects2.length = 0;
gdjs.EndCode.GDWallLeftObjects1.length = 0;
gdjs.EndCode.GDWallLeftObjects2.length = 0;
gdjs.EndCode.GDCeilLeftObjects1.length = 0;
gdjs.EndCode.GDCeilLeftObjects2.length = 0;
gdjs.EndCode.GDCeilTileObjects1.length = 0;
gdjs.EndCode.GDCeilTileObjects2.length = 0;
gdjs.EndCode.GDCeilRightObjects1.length = 0;
gdjs.EndCode.GDCeilRightObjects2.length = 0;
gdjs.EndCode.GDCornerBRObjects1.length = 0;
gdjs.EndCode.GDCornerBRObjects2.length = 0;
gdjs.EndCode.GDCornerBLObjects1.length = 0;
gdjs.EndCode.GDCornerBLObjects2.length = 0;
gdjs.EndCode.GDCornerTLObjects1.length = 0;
gdjs.EndCode.GDCornerTLObjects2.length = 0;
gdjs.EndCode.GDCornerTRObjects1.length = 0;
gdjs.EndCode.GDCornerTRObjects2.length = 0;
gdjs.EndCode.GDHoverTileHorizontalObjects1.length = 0;
gdjs.EndCode.GDHoverTileHorizontalObjects2.length = 0;
gdjs.EndCode.GDHoverTileRObjects1.length = 0;
gdjs.EndCode.GDHoverTileRObjects2.length = 0;
gdjs.EndCode.GDHoverTileLObjects1.length = 0;
gdjs.EndCode.GDHoverTileLObjects2.length = 0;
gdjs.EndCode.GDTileObjects1.length = 0;
gdjs.EndCode.GDTileObjects2.length = 0;
gdjs.EndCode.GDBGTileObjects1.length = 0;
gdjs.EndCode.GDBGTileObjects2.length = 0;
gdjs.EndCode.GDCreditsObjects1.length = 0;
gdjs.EndCode.GDCreditsObjects2.length = 0;
gdjs.EndCode.GDNewObjectObjects1.length = 0;
gdjs.EndCode.GDNewObjectObjects2.length = 0;

gdjs.EndCode.eventsList0(runtimeScene);
return;

}

gdjs['EndCode'] = gdjs.EndCode;
