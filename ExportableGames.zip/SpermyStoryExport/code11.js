gdjs.CongratsCode = {};
gdjs.CongratsCode.GDFloorTileObjects1= [];
gdjs.CongratsCode.GDFloorTileObjects2= [];
gdjs.CongratsCode.GDCliffRightObjects1= [];
gdjs.CongratsCode.GDCliffRightObjects2= [];
gdjs.CongratsCode.GDWallRightObjects1= [];
gdjs.CongratsCode.GDWallRightObjects2= [];
gdjs.CongratsCode.GDCliffLeftObjects1= [];
gdjs.CongratsCode.GDCliffLeftObjects2= [];
gdjs.CongratsCode.GDWallLeftObjects1= [];
gdjs.CongratsCode.GDWallLeftObjects2= [];
gdjs.CongratsCode.GDCeilLeftObjects1= [];
gdjs.CongratsCode.GDCeilLeftObjects2= [];
gdjs.CongratsCode.GDCeilTileObjects1= [];
gdjs.CongratsCode.GDCeilTileObjects2= [];
gdjs.CongratsCode.GDCeilRightObjects1= [];
gdjs.CongratsCode.GDCeilRightObjects2= [];
gdjs.CongratsCode.GDCornerBRObjects1= [];
gdjs.CongratsCode.GDCornerBRObjects2= [];
gdjs.CongratsCode.GDCornerBLObjects1= [];
gdjs.CongratsCode.GDCornerBLObjects2= [];
gdjs.CongratsCode.GDCornerTLObjects1= [];
gdjs.CongratsCode.GDCornerTLObjects2= [];
gdjs.CongratsCode.GDCornerTRObjects1= [];
gdjs.CongratsCode.GDCornerTRObjects2= [];
gdjs.CongratsCode.GDHoverTileHorizontalObjects1= [];
gdjs.CongratsCode.GDHoverTileHorizontalObjects2= [];
gdjs.CongratsCode.GDHoverTileRObjects1= [];
gdjs.CongratsCode.GDHoverTileRObjects2= [];
gdjs.CongratsCode.GDHoverTileLObjects1= [];
gdjs.CongratsCode.GDHoverTileLObjects2= [];
gdjs.CongratsCode.GDTileObjects1= [];
gdjs.CongratsCode.GDTileObjects2= [];
gdjs.CongratsCode.GDBGTileObjects1= [];
gdjs.CongratsCode.GDBGTileObjects2= [];
gdjs.CongratsCode.GDDescObjects1= [];
gdjs.CongratsCode.GDDescObjects2= [];
gdjs.CongratsCode.GDNewObjectObjects1= [];
gdjs.CongratsCode.GDNewObjectObjects2= [];

gdjs.CongratsCode.conditionTrue_0 = {val:false};
gdjs.CongratsCode.condition0IsTrue_0 = {val:false};
gdjs.CongratsCode.condition1IsTrue_0 = {val:false};
gdjs.CongratsCode.condition2IsTrue_0 = {val:false};


gdjs.CongratsCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Desc"), gdjs.CongratsCode.GDDescObjects1);
{for(var i = 0, len = gdjs.CongratsCode.GDDescObjects1.length ;i < len;++i) {
    gdjs.CongratsCode.GDDescObjects1[i].setTextAlignment("center");
}
}}

}


{


gdjs.CongratsCode.condition0IsTrue_0.val = false;
{
gdjs.CongratsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.CongratsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End", false);
}}

}


{


{
}

}


};

gdjs.CongratsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CongratsCode.GDFloorTileObjects1.length = 0;
gdjs.CongratsCode.GDFloorTileObjects2.length = 0;
gdjs.CongratsCode.GDCliffRightObjects1.length = 0;
gdjs.CongratsCode.GDCliffRightObjects2.length = 0;
gdjs.CongratsCode.GDWallRightObjects1.length = 0;
gdjs.CongratsCode.GDWallRightObjects2.length = 0;
gdjs.CongratsCode.GDCliffLeftObjects1.length = 0;
gdjs.CongratsCode.GDCliffLeftObjects2.length = 0;
gdjs.CongratsCode.GDWallLeftObjects1.length = 0;
gdjs.CongratsCode.GDWallLeftObjects2.length = 0;
gdjs.CongratsCode.GDCeilLeftObjects1.length = 0;
gdjs.CongratsCode.GDCeilLeftObjects2.length = 0;
gdjs.CongratsCode.GDCeilTileObjects1.length = 0;
gdjs.CongratsCode.GDCeilTileObjects2.length = 0;
gdjs.CongratsCode.GDCeilRightObjects1.length = 0;
gdjs.CongratsCode.GDCeilRightObjects2.length = 0;
gdjs.CongratsCode.GDCornerBRObjects1.length = 0;
gdjs.CongratsCode.GDCornerBRObjects2.length = 0;
gdjs.CongratsCode.GDCornerBLObjects1.length = 0;
gdjs.CongratsCode.GDCornerBLObjects2.length = 0;
gdjs.CongratsCode.GDCornerTLObjects1.length = 0;
gdjs.CongratsCode.GDCornerTLObjects2.length = 0;
gdjs.CongratsCode.GDCornerTRObjects1.length = 0;
gdjs.CongratsCode.GDCornerTRObjects2.length = 0;
gdjs.CongratsCode.GDHoverTileHorizontalObjects1.length = 0;
gdjs.CongratsCode.GDHoverTileHorizontalObjects2.length = 0;
gdjs.CongratsCode.GDHoverTileRObjects1.length = 0;
gdjs.CongratsCode.GDHoverTileRObjects2.length = 0;
gdjs.CongratsCode.GDHoverTileLObjects1.length = 0;
gdjs.CongratsCode.GDHoverTileLObjects2.length = 0;
gdjs.CongratsCode.GDTileObjects1.length = 0;
gdjs.CongratsCode.GDTileObjects2.length = 0;
gdjs.CongratsCode.GDBGTileObjects1.length = 0;
gdjs.CongratsCode.GDBGTileObjects2.length = 0;
gdjs.CongratsCode.GDDescObjects1.length = 0;
gdjs.CongratsCode.GDDescObjects2.length = 0;
gdjs.CongratsCode.GDNewObjectObjects1.length = 0;
gdjs.CongratsCode.GDNewObjectObjects2.length = 0;

gdjs.CongratsCode.eventsList0(runtimeScene);
return;

}

gdjs['CongratsCode'] = gdjs.CongratsCode;
