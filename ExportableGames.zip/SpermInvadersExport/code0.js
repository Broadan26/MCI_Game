gdjs.TitleCode = {};
gdjs.TitleCode.GDSplashIntroObjects1= [];
gdjs.TitleCode.GDSplashIntroObjects2= [];
gdjs.TitleCode.GDTextboxObjects1= [];
gdjs.TitleCode.GDTextboxObjects2= [];

gdjs.TitleCode.conditionTrue_0 = {val:false};
gdjs.TitleCode.condition0IsTrue_0 = {val:false};
gdjs.TitleCode.condition1IsTrue_0 = {val:false};


gdjs.TitleCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.TitleCode.condition0IsTrue_0.val = false;
{
gdjs.TitleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TitleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Sounds\\Sperm Invaders Menu.wav", true, 100, 1);
}{runtimeScene.getGame().getVariables().get("Live").setNumber(3);
}}

}


{



}


{


gdjs.TitleCode.condition0IsTrue_0.val = false;
{
gdjs.TitleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
}if (gdjs.TitleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Info", false);
}}

}


};

gdjs.TitleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TitleCode.GDSplashIntroObjects1.length = 0;
gdjs.TitleCode.GDSplashIntroObjects2.length = 0;
gdjs.TitleCode.GDTextboxObjects1.length = 0;
gdjs.TitleCode.GDTextboxObjects2.length = 0;

gdjs.TitleCode.eventsList0(runtimeScene);
return;

}

gdjs['TitleCode'] = gdjs.TitleCode;
