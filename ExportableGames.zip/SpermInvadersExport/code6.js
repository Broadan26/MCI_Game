gdjs.Level01EasyCode = {};
gdjs.Level01EasyCode.GDPlayerObjects1_1final = [];

gdjs.Level01EasyCode.GDPlayerObjects1= [];
gdjs.Level01EasyCode.GDPlayerObjects2= [];
gdjs.Level01EasyCode.GDScoreObjects1= [];
gdjs.Level01EasyCode.GDScoreObjects2= [];
gdjs.Level01EasyCode.GDBulletObjects1= [];
gdjs.Level01EasyCode.GDBulletObjects2= [];
gdjs.Level01EasyCode.GDEnemyObjects1= [];
gdjs.Level01EasyCode.GDEnemyObjects2= [];
gdjs.Level01EasyCode.GDBackgroundTileObjects1= [];
gdjs.Level01EasyCode.GDBackgroundTileObjects2= [];
gdjs.Level01EasyCode.GDLivesObjects1= [];
gdjs.Level01EasyCode.GDLivesObjects2= [];
gdjs.Level01EasyCode.GDTotalObjects1= [];
gdjs.Level01EasyCode.GDTotalObjects2= [];
gdjs.Level01EasyCode.GDEnemy2Objects1= [];
gdjs.Level01EasyCode.GDEnemy2Objects2= [];

gdjs.Level01EasyCode.conditionTrue_0 = {val:false};
gdjs.Level01EasyCode.condition0IsTrue_0 = {val:false};
gdjs.Level01EasyCode.condition1IsTrue_0 = {val:false};
gdjs.Level01EasyCode.condition2IsTrue_0 = {val:false};
gdjs.Level01EasyCode.condition3IsTrue_0 = {val:false};
gdjs.Level01EasyCode.conditionTrue_1 = {val:false};
gdjs.Level01EasyCode.condition0IsTrue_1 = {val:false};
gdjs.Level01EasyCode.condition1IsTrue_1 = {val:false};
gdjs.Level01EasyCode.condition2IsTrue_1 = {val:false};
gdjs.Level01EasyCode.condition3IsTrue_1 = {val:false};
gdjs.Level01EasyCode.conditionTrue_2 = {val:false};
gdjs.Level01EasyCode.condition0IsTrue_2 = {val:false};
gdjs.Level01EasyCode.condition1IsTrue_2 = {val:false};
gdjs.Level01EasyCode.condition2IsTrue_2 = {val:false};
gdjs.Level01EasyCode.condition3IsTrue_2 = {val:false};


gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01EasyCode.GDBulletObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01EasyCode.GDBulletObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01EasyCode.GDEnemyObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01EasyCode.GDEnemyObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01EasyCode.GDEnemyObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01EasyCode.GDBulletObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemy2Objects1Objects = Hashtable.newFrom({"Enemy2": gdjs.Level01EasyCode.GDEnemy2Objects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level01EasyCode.GDPlayerObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01EasyCode.GDEnemyObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level01EasyCode.GDPlayerObjects1});gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemy2Objects1Objects = Hashtable.newFrom({"Enemy2": gdjs.Level01EasyCode.GDEnemy2Objects1});gdjs.Level01EasyCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01EasyCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01EasyCode.GDScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01EasyCode.GDTotalObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Sounds\\Theme.wav", true, 100, 1);
}{runtimeScene.getGame().getVariables().get("Live").setNumber(10);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}}

}


{



}


{


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition0IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live")) == 0;
}gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", true);
}}

}


{



}


{


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", true);
}}

}


{



}


{

gdjs.Level01EasyCode.GDPlayerObjects1.length = 0;


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition0IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getX() > -(15) ) {
        gdjs.Level01EasyCode.condition0IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition1IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getX() > -(15) ) {
        gdjs.Level01EasyCode.condition0IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition1IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01EasyCode.GDPlayerObjects1_1final, gdjs.Level01EasyCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].addForce(-(300), 0, 0);
}
}}

}


{

gdjs.Level01EasyCode.GDPlayerObjects1.length = 0;


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition0IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getX() < 750 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition1IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getX() < 750 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition1IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01EasyCode.GDPlayerObjects1_1final, gdjs.Level01EasyCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].addForce(300, 0, 0);
}
}}

}


{

gdjs.Level01EasyCode.GDPlayerObjects1.length = 0;


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition0IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getY() > 0 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition1IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getY() > 0 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition1IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01EasyCode.GDPlayerObjects1_1final, gdjs.Level01EasyCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].addForce(0, -(250), 0);
}
}}

}


{

gdjs.Level01EasyCode.GDPlayerObjects1.length = 0;


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition0IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getY() < 520 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects2);
{gdjs.Level01EasyCode.conditionTrue_2 = gdjs.Level01EasyCode.condition1IsTrue_1;
gdjs.Level01EasyCode.condition0IsTrue_2.val = false;
gdjs.Level01EasyCode.condition1IsTrue_2.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.Level01EasyCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects2[i].getY() < 520 ) {
        gdjs.Level01EasyCode.condition1IsTrue_2.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects2[k] = gdjs.Level01EasyCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects2.length = k;}}
gdjs.Level01EasyCode.conditionTrue_2.val = true && gdjs.Level01EasyCode.condition0IsTrue_2.val && gdjs.Level01EasyCode.condition1IsTrue_2.val;
}
if( gdjs.Level01EasyCode.condition1IsTrue_1.val ) {
    gdjs.Level01EasyCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01EasyCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01EasyCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01EasyCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01EasyCode.GDPlayerObjects1_1final.push(gdjs.Level01EasyCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01EasyCode.GDPlayerObjects1_1final, gdjs.Level01EasyCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].addForce(0, 250, 0);
}
}}

}


{


gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
gdjs.Level01EasyCode.condition1IsTrue_0.val = false;
gdjs.Level01EasyCode.condition2IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.Level01EasyCode.condition0IsTrue_0.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "firerate");
}if ( gdjs.Level01EasyCode.condition1IsTrue_0.val ) {
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition2IsTrue_0;
gdjs.Level01EasyCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12935084);
}
}}
}
if (gdjs.Level01EasyCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects1);
gdjs.Level01EasyCode.GDBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].setAnimation(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects, (( gdjs.Level01EasyCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level01EasyCode.GDPlayerObjects1[0].getPointX("")) - 5, (( gdjs.Level01EasyCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level01EasyCode.GDPlayerObjects1[0].getPointY("")) - 30, "");
}{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].setScale(gdjs.Level01EasyCode.GDBulletObjects1[i].getScale() * (1.5));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].addForce(0, -(300), 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Assets\\Sounds\\Laser Shot.wav", false, 100, 25);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "firerate");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
gdjs.Level01EasyCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects1[i].getAnimation() == 1 ) {
        gdjs.Level01EasyCode.condition0IsTrue_0.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects1[k] = gdjs.Level01EasyCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects1.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDPlayerObjects1[i].hasAnimationEnded() ) {
        gdjs.Level01EasyCode.condition1IsTrue_0.val = true;
        gdjs.Level01EasyCode.GDPlayerObjects1[k] = gdjs.Level01EasyCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDPlayerObjects1.length = k;}}
if (gdjs.Level01EasyCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDPlayerObjects1[i].setAnimation(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01EasyCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects, gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDBulletObjects1 */
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01EasyCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects, gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects, false, runtimeScene, true);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01EasyCode.GDBulletObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDBulletObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDBulletObjects1[i].getY() < -(20) ) {
        gdjs.Level01EasyCode.condition0IsTrue_0.val = true;
        gdjs.Level01EasyCode.GDBulletObjects1[k] = gdjs.Level01EasyCode.GDBulletObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDBulletObjects1.length = k;}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01EasyCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01EasyCode.GDEnemy2Objects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDBulletObjects1Objects, gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemy2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDBulletObjects1 */
/* Reuse gdjs.Level01EasyCode.GDEnemy2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01EasyCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01EasyCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setX(gdjs.randomInRange(0, 750));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemyObjects1[i].getAverageForce().getLength() < 30 ) {
        gdjs.Level01EasyCode.condition0IsTrue_1.val = true;
        gdjs.Level01EasyCode.GDEnemyObjects1[k] = gdjs.Level01EasyCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemyObjects1.length = k;}gdjs.Level01EasyCode.conditionTrue_1.val = true && gdjs.Level01EasyCode.condition0IsTrue_1.val;
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].addForce(0, 30, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01EasyCode.GDEnemy2Objects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemy2Objects1[i].getAverageForce().getLength() < 50 ) {
        gdjs.Level01EasyCode.condition0IsTrue_1.val = true;
        gdjs.Level01EasyCode.GDEnemy2Objects1[k] = gdjs.Level01EasyCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemy2Objects1.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 60;
}}
gdjs.Level01EasyCode.conditionTrue_1.val = true && gdjs.Level01EasyCode.condition0IsTrue_1.val && gdjs.Level01EasyCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemy2Objects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].addForce(0, 50, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemyObjects1[i].getAverageForce().getLength() < 40 ) {
        gdjs.Level01EasyCode.condition0IsTrue_1.val = true;
        gdjs.Level01EasyCode.GDEnemyObjects1[k] = gdjs.Level01EasyCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemyObjects1.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 200;
}}
gdjs.Level01EasyCode.conditionTrue_1.val = true && gdjs.Level01EasyCode.condition0IsTrue_1.val && gdjs.Level01EasyCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemyObjects1[i].getAverageForce().getLength() < 50 ) {
        gdjs.Level01EasyCode.condition0IsTrue_1.val = true;
        gdjs.Level01EasyCode.GDEnemyObjects1[k] = gdjs.Level01EasyCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemyObjects1.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 400;
}}
gdjs.Level01EasyCode.conditionTrue_1.val = true && gdjs.Level01EasyCode.condition0IsTrue_1.val && gdjs.Level01EasyCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01EasyCode.GDEnemy2Objects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01EasyCode.conditionTrue_1 = gdjs.Level01EasyCode.condition0IsTrue_0;
gdjs.Level01EasyCode.condition0IsTrue_1.val = false;
gdjs.Level01EasyCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemy2Objects1[i].getAverageForce().getLength() < 55 ) {
        gdjs.Level01EasyCode.condition0IsTrue_1.val = true;
        gdjs.Level01EasyCode.GDEnemy2Objects1[k] = gdjs.Level01EasyCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemy2Objects1.length = k;}if ( gdjs.Level01EasyCode.condition0IsTrue_1.val ) {
{
gdjs.Level01EasyCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 600;
}}
gdjs.Level01EasyCode.conditionTrue_1.val = true && gdjs.Level01EasyCode.condition0IsTrue_1.val && gdjs.Level01EasyCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemy2Objects1 */
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemyObjects1[i].getY() > 608 ) {
        gdjs.Level01EasyCode.condition0IsTrue_0.val = true;
        gdjs.Level01EasyCode.GDEnemyObjects1[k] = gdjs.Level01EasyCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemyObjects1.length = k;}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01EasyCode.GDTotalObjects1);
{runtimeScene.getGame().getVariables().get("Live").sub(1);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01EasyCode.GDEnemy2Objects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01EasyCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.Level01EasyCode.GDEnemy2Objects1[i].getY() > 608 ) {
        gdjs.Level01EasyCode.condition0IsTrue_0.val = true;
        gdjs.Level01EasyCode.GDEnemy2Objects1[k] = gdjs.Level01EasyCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.Level01EasyCode.GDEnemy2Objects1.length = k;}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemy2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01EasyCode.GDTotalObjects1);
{runtimeScene.getGame().getVariables().get("Live").sub(1);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setX(gdjs.randomInRange(0, 750));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01EasyCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDPlayerObjects1Objects, gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01EasyCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(5);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01EasyCode.GDEnemy2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01EasyCode.GDPlayerObjects1);

gdjs.Level01EasyCode.condition0IsTrue_0.val = false;
{
gdjs.Level01EasyCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDPlayerObjects1Objects, gdjs.Level01EasyCode.mapOfGDgdjs_46Level01EasyCode_46GDEnemy2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level01EasyCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01EasyCode.GDEnemy2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01EasyCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01EasyCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDEnemy2Objects1[i].setX(gdjs.randomInRange(0, 750));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(5);
}{for(var i = 0, len = gdjs.Level01EasyCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01EasyCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{


{
}

}


};

gdjs.Level01EasyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level01EasyCode.GDPlayerObjects1.length = 0;
gdjs.Level01EasyCode.GDPlayerObjects2.length = 0;
gdjs.Level01EasyCode.GDScoreObjects1.length = 0;
gdjs.Level01EasyCode.GDScoreObjects2.length = 0;
gdjs.Level01EasyCode.GDBulletObjects1.length = 0;
gdjs.Level01EasyCode.GDBulletObjects2.length = 0;
gdjs.Level01EasyCode.GDEnemyObjects1.length = 0;
gdjs.Level01EasyCode.GDEnemyObjects2.length = 0;
gdjs.Level01EasyCode.GDBackgroundTileObjects1.length = 0;
gdjs.Level01EasyCode.GDBackgroundTileObjects2.length = 0;
gdjs.Level01EasyCode.GDLivesObjects1.length = 0;
gdjs.Level01EasyCode.GDLivesObjects2.length = 0;
gdjs.Level01EasyCode.GDTotalObjects1.length = 0;
gdjs.Level01EasyCode.GDTotalObjects2.length = 0;
gdjs.Level01EasyCode.GDEnemy2Objects1.length = 0;
gdjs.Level01EasyCode.GDEnemy2Objects2.length = 0;

gdjs.Level01EasyCode.eventsList0(runtimeScene);
return;

}

gdjs['Level01EasyCode'] = gdjs.Level01EasyCode;
