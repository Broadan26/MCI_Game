gdjs.DifficultyCode = {};
gdjs.DifficultyCode.GDTitleObjects1= [];
gdjs.DifficultyCode.GDTitleObjects2= [];
gdjs.DifficultyCode.GDEASYObjects1= [];
gdjs.DifficultyCode.GDEASYObjects2= [];
gdjs.DifficultyCode.GDMEDIUMObjects1= [];
gdjs.DifficultyCode.GDMEDIUMObjects2= [];
gdjs.DifficultyCode.GDHARDObjects1= [];
gdjs.DifficultyCode.GDHARDObjects2= [];

gdjs.DifficultyCode.conditionTrue_0 = {val:false};
gdjs.DifficultyCode.condition0IsTrue_0 = {val:false};
gdjs.DifficultyCode.condition1IsTrue_0 = {val:false};
gdjs.DifficultyCode.condition2IsTrue_0 = {val:false};
gdjs.DifficultyCode.conditionTrue_1 = {val:false};
gdjs.DifficultyCode.condition0IsTrue_1 = {val:false};
gdjs.DifficultyCode.condition1IsTrue_1 = {val:false};
gdjs.DifficultyCode.condition2IsTrue_1 = {val:false};


gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDEASYObjects1Objects = Hashtable.newFrom({"EASY": gdjs.DifficultyCode.GDEASYObjects1});gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDMEDIUMObjects1Objects = Hashtable.newFrom({"MEDIUM": gdjs.DifficultyCode.GDMEDIUMObjects1});gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDHARDObjects1Objects = Hashtable.newFrom({"HARD": gdjs.DifficultyCode.GDHARDObjects1});gdjs.DifficultyCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.DifficultyCode.condition0IsTrue_0.val = false;
{
gdjs.DifficultyCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.DifficultyCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EASY"), gdjs.DifficultyCode.GDEASYObjects1);
gdjs.copyArray(runtimeScene.getObjects("HARD"), gdjs.DifficultyCode.GDHARDObjects1);
gdjs.copyArray(runtimeScene.getObjects("MEDIUM"), gdjs.DifficultyCode.GDMEDIUMObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.DifficultyCode.GDTitleObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.DifficultyCode.GDTitleObjects1.length ;i < len;++i) {
    gdjs.DifficultyCode.GDTitleObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.DifficultyCode.GDEASYObjects1.length ;i < len;++i) {
    gdjs.DifficultyCode.GDEASYObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.DifficultyCode.GDMEDIUMObjects1.length ;i < len;++i) {
    gdjs.DifficultyCode.GDMEDIUMObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.DifficultyCode.GDHARDObjects1.length ;i < len;++i) {
    gdjs.DifficultyCode.GDHARDObjects1[i].setTextAlignment("center");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EASY"), gdjs.DifficultyCode.GDEASYObjects1);

gdjs.DifficultyCode.condition0IsTrue_0.val = false;
{
{gdjs.DifficultyCode.conditionTrue_1 = gdjs.DifficultyCode.condition0IsTrue_0;
gdjs.DifficultyCode.condition0IsTrue_1.val = false;
gdjs.DifficultyCode.condition1IsTrue_1.val = false;
{
gdjs.DifficultyCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDEASYObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DifficultyCode.condition0IsTrue_1.val ) {
{
gdjs.DifficultyCode.condition1IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.DifficultyCode.conditionTrue_1.val = true && gdjs.DifficultyCode.condition0IsTrue_1.val && gdjs.DifficultyCode.condition1IsTrue_1.val;
}
}if (gdjs.DifficultyCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MEDIUM"), gdjs.DifficultyCode.GDMEDIUMObjects1);

gdjs.DifficultyCode.condition0IsTrue_0.val = false;
{
{gdjs.DifficultyCode.conditionTrue_1 = gdjs.DifficultyCode.condition0IsTrue_0;
gdjs.DifficultyCode.condition0IsTrue_1.val = false;
gdjs.DifficultyCode.condition1IsTrue_1.val = false;
{
gdjs.DifficultyCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDMEDIUMObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DifficultyCode.condition0IsTrue_1.val ) {
{
gdjs.DifficultyCode.condition1IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.DifficultyCode.conditionTrue_1.val = true && gdjs.DifficultyCode.condition0IsTrue_1.val && gdjs.DifficultyCode.condition1IsTrue_1.val;
}
}if (gdjs.DifficultyCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HARD"), gdjs.DifficultyCode.GDHARDObjects1);

gdjs.DifficultyCode.condition0IsTrue_0.val = false;
{
{gdjs.DifficultyCode.conditionTrue_1 = gdjs.DifficultyCode.condition0IsTrue_0;
gdjs.DifficultyCode.condition0IsTrue_1.val = false;
gdjs.DifficultyCode.condition1IsTrue_1.val = false;
{
gdjs.DifficultyCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.DifficultyCode.mapOfGDgdjs_46DifficultyCode_46GDHARDObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DifficultyCode.condition0IsTrue_1.val ) {
{
gdjs.DifficultyCode.condition1IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.DifficultyCode.conditionTrue_1.val = true && gdjs.DifficultyCode.condition0IsTrue_1.val && gdjs.DifficultyCode.condition1IsTrue_1.val;
}
}if (gdjs.DifficultyCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}}

}


{


{
}

}


};

gdjs.DifficultyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DifficultyCode.GDTitleObjects1.length = 0;
gdjs.DifficultyCode.GDTitleObjects2.length = 0;
gdjs.DifficultyCode.GDEASYObjects1.length = 0;
gdjs.DifficultyCode.GDEASYObjects2.length = 0;
gdjs.DifficultyCode.GDMEDIUMObjects1.length = 0;
gdjs.DifficultyCode.GDMEDIUMObjects2.length = 0;
gdjs.DifficultyCode.GDHARDObjects1.length = 0;
gdjs.DifficultyCode.GDHARDObjects2.length = 0;

gdjs.DifficultyCode.eventsList0(runtimeScene);
return;

}

gdjs['DifficultyCode'] = gdjs.DifficultyCode;
