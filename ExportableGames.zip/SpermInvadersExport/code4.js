gdjs.Level01HardCode = {};
gdjs.Level01HardCode.GDEnemy2Objects1_1final = [];

gdjs.Level01HardCode.GDEnemyObjects1_1final = [];

gdjs.Level01HardCode.GDPlayerObjects1_1final = [];

gdjs.Level01HardCode.GDPlayerObjects1= [];
gdjs.Level01HardCode.GDPlayerObjects2= [];
gdjs.Level01HardCode.GDScoreObjects1= [];
gdjs.Level01HardCode.GDScoreObjects2= [];
gdjs.Level01HardCode.GDBulletObjects1= [];
gdjs.Level01HardCode.GDBulletObjects2= [];
gdjs.Level01HardCode.GDEnemyObjects1= [];
gdjs.Level01HardCode.GDEnemyObjects2= [];
gdjs.Level01HardCode.GDBackgroundTileObjects1= [];
gdjs.Level01HardCode.GDBackgroundTileObjects2= [];
gdjs.Level01HardCode.GDLivesObjects1= [];
gdjs.Level01HardCode.GDLivesObjects2= [];
gdjs.Level01HardCode.GDTotalObjects1= [];
gdjs.Level01HardCode.GDTotalObjects2= [];
gdjs.Level01HardCode.GDHIVSpawnObjects1= [];
gdjs.Level01HardCode.GDHIVSpawnObjects2= [];
gdjs.Level01HardCode.GDHIVMiniObjects1= [];
gdjs.Level01HardCode.GDHIVMiniObjects2= [];
gdjs.Level01HardCode.GDEnemy2Objects1= [];
gdjs.Level01HardCode.GDEnemy2Objects2= [];

gdjs.Level01HardCode.conditionTrue_0 = {val:false};
gdjs.Level01HardCode.condition0IsTrue_0 = {val:false};
gdjs.Level01HardCode.condition1IsTrue_0 = {val:false};
gdjs.Level01HardCode.condition2IsTrue_0 = {val:false};
gdjs.Level01HardCode.condition3IsTrue_0 = {val:false};
gdjs.Level01HardCode.conditionTrue_1 = {val:false};
gdjs.Level01HardCode.condition0IsTrue_1 = {val:false};
gdjs.Level01HardCode.condition1IsTrue_1 = {val:false};
gdjs.Level01HardCode.condition2IsTrue_1 = {val:false};
gdjs.Level01HardCode.condition3IsTrue_1 = {val:false};
gdjs.Level01HardCode.conditionTrue_2 = {val:false};
gdjs.Level01HardCode.condition0IsTrue_2 = {val:false};
gdjs.Level01HardCode.condition1IsTrue_2 = {val:false};
gdjs.Level01HardCode.condition2IsTrue_2 = {val:false};
gdjs.Level01HardCode.condition3IsTrue_2 = {val:false};


gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01HardCode.GDBulletObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01HardCode.GDBulletObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01HardCode.GDEnemyObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01HardCode.GDBulletObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemy2Objects1Objects = Hashtable.newFrom({"Enemy2": gdjs.Level01HardCode.GDEnemy2Objects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01HardCode.GDEnemyObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01HardCode.GDEnemyObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level01HardCode.GDBulletObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects = Hashtable.newFrom({"HIVMini": gdjs.Level01HardCode.GDHIVMiniObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level01HardCode.GDPlayerObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Level01HardCode.GDEnemyObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level01HardCode.GDPlayerObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects = Hashtable.newFrom({"HIVMini": gdjs.Level01HardCode.GDHIVMiniObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level01HardCode.GDPlayerObjects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemy2Objects1Objects = Hashtable.newFrom({"Enemy2": gdjs.Level01HardCode.GDEnemy2Objects1});gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects = Hashtable.newFrom({"HIVMini": gdjs.Level01HardCode.GDHIVMiniObjects1});gdjs.Level01HardCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01HardCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01HardCode.GDTotalObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets\\Sounds\\Theme03.wav", true, 100, 1);
}{runtimeScene.getGame().getVariables().get("Live").setNumber(10);
}{for(var i = 0, len = gdjs.Level01HardCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].resetTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].pauseTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].resetTimer("HIVTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}}

}


{



}


{


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live")) == 0;
}gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", true);
}}

}


{



}


{


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{



}


{

gdjs.Level01HardCode.GDPlayerObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getX() > -(15) ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition1IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getX() > -(15) ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDPlayerObjects1_1final, gdjs.Level01HardCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].addForce(-(300), 0, 0);
}
}}

}


{

gdjs.Level01HardCode.GDPlayerObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getX() < 750 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition1IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getX() < 750 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDPlayerObjects1_1final, gdjs.Level01HardCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].addForce(300, 0, 0);
}
}}

}


{

gdjs.Level01HardCode.GDPlayerObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getY() > 0 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition1IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getY() > 0 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDPlayerObjects1_1final, gdjs.Level01HardCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].addForce(0, -(250), 0);
}
}}

}


{

gdjs.Level01HardCode.GDPlayerObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDPlayerObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getY() < 520 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition1IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects2[i].getY() < 520 ) {
        gdjs.Level01HardCode.condition1IsTrue_2.val = true;
        gdjs.Level01HardCode.GDPlayerObjects2[k] = gdjs.Level01HardCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects2.length = k;}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDPlayerObjects1_1final.indexOf(gdjs.Level01HardCode.GDPlayerObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDPlayerObjects1_1final.push(gdjs.Level01HardCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDPlayerObjects1_1final, gdjs.Level01HardCode.GDPlayerObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].addForce(0, 250, 0);
}
}}

}


{


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
gdjs.Level01HardCode.condition1IsTrue_0.val = false;
gdjs.Level01HardCode.condition2IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.Level01HardCode.condition0IsTrue_0.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "firerate");
}if ( gdjs.Level01HardCode.condition1IsTrue_0.val ) {
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition2IsTrue_0;
gdjs.Level01HardCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12767420);
}
}}
}
if (gdjs.Level01HardCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects1);
gdjs.Level01HardCode.GDBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].setAnimation(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects, (( gdjs.Level01HardCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level01HardCode.GDPlayerObjects1[0].getPointX("")) + 20, (( gdjs.Level01HardCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level01HardCode.GDPlayerObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].setScale(gdjs.Level01HardCode.GDBulletObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].addForce(0, -(300), 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Assets\\Sounds\\Laser Shot.wav", false, 100, 25);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "firerate");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
gdjs.Level01HardCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects1[i].getAnimation() == 1 ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDPlayerObjects1[k] = gdjs.Level01HardCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDPlayerObjects1[i].hasAnimationEnded() ) {
        gdjs.Level01HardCode.condition1IsTrue_0.val = true;
        gdjs.Level01HardCode.GDPlayerObjects1[k] = gdjs.Level01HardCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDPlayerObjects1.length = k;}}
if (gdjs.Level01HardCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDPlayerObjects1[i].setAnimation(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01HardCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDBulletObjects1 */
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01HardCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemy2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDBulletObjects1 */
/* Reuse gdjs.Level01HardCode.GDEnemy2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].setX(gdjs.randomInRange(0, 750));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01HardCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("HIVMini"), gdjs.Level01HardCode.GDHIVMiniObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDBulletObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDBulletObjects1 */
/* Reuse gdjs.Level01HardCode.GDHIVMiniObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVMiniObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVMiniObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level01HardCode.GDBulletObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDBulletObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDBulletObjects1[i].getY() < -(5) ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDBulletObjects1[k] = gdjs.Level01HardCode.GDBulletObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDBulletObjects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemyObjects1[i].getAverageForce().getLength() < 40 ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDEnemyObjects1[k] = gdjs.Level01HardCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemyObjects1.length = k;}gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].addForce(0, 40, 1);
}
}}

}


{

gdjs.Level01HardCode.GDEnemy2Objects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDEnemy2Objects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemy2Objects2[i].getAverageForce().getLength() < 40 ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDEnemy2Objects2[k] = gdjs.Level01HardCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemy2Objects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 100;
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDEnemy2Objects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDEnemy2Objects1_1final.indexOf(gdjs.Level01HardCode.GDEnemy2Objects2[j]) === -1 )
            gdjs.Level01HardCode.GDEnemy2Objects1_1final.push(gdjs.Level01HardCode.GDEnemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDEnemy2Objects1_1final, gdjs.Level01HardCode.GDEnemy2Objects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemy2Objects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].addForce(0, 40, 1);
}
}}

}


{

gdjs.Level01HardCode.GDEnemyObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDEnemyObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemyObjects2[i].getAverageForce().getLength() < 50 ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDEnemyObjects2[k] = gdjs.Level01HardCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemyObjects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 250;
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDEnemyObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDEnemyObjects1_1final.indexOf(gdjs.Level01HardCode.GDEnemyObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDEnemyObjects1_1final.push(gdjs.Level01HardCode.GDEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDEnemyObjects1_1final, gdjs.Level01HardCode.GDEnemyObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.Level01HardCode.GDEnemy2Objects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDEnemy2Objects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemy2Objects2[i].getAverageForce().getLength() < 50 ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDEnemy2Objects2[k] = gdjs.Level01HardCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemy2Objects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 500;
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDEnemy2Objects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDEnemy2Objects1_1final.indexOf(gdjs.Level01HardCode.GDEnemy2Objects2[j]) === -1 )
            gdjs.Level01HardCode.GDEnemy2Objects1_1final.push(gdjs.Level01HardCode.GDEnemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDEnemy2Objects1_1final, gdjs.Level01HardCode.GDEnemy2Objects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemy2Objects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.Level01HardCode.GDEnemyObjects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDEnemyObjects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemyObjects2[i].getAverageForce().getLength() < 60 ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDEnemyObjects2[k] = gdjs.Level01HardCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemyObjects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 650;
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDEnemyObjects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDEnemyObjects1_1final.indexOf(gdjs.Level01HardCode.GDEnemyObjects2[j]) === -1 )
            gdjs.Level01HardCode.GDEnemyObjects1_1final.push(gdjs.Level01HardCode.GDEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDEnemyObjects1_1final, gdjs.Level01HardCode.GDEnemyObjects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.Level01HardCode.GDEnemy2Objects1.length = 0;


gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.GDEnemy2Objects1_1final.length = 0;gdjs.Level01HardCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects2);
{gdjs.Level01HardCode.conditionTrue_2 = gdjs.Level01HardCode.condition0IsTrue_1;
gdjs.Level01HardCode.condition0IsTrue_2.val = false;
gdjs.Level01HardCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemy2Objects2[i].getAverageForce().getLength() < 60 ) {
        gdjs.Level01HardCode.condition0IsTrue_2.val = true;
        gdjs.Level01HardCode.GDEnemy2Objects2[k] = gdjs.Level01HardCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemy2Objects2.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_2.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 800;
}}
gdjs.Level01HardCode.conditionTrue_2.val = true && gdjs.Level01HardCode.condition0IsTrue_2.val && gdjs.Level01HardCode.condition1IsTrue_2.val;
}
if( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
    gdjs.Level01HardCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level01HardCode.GDEnemy2Objects2.length;j<jLen;++j) {
        if ( gdjs.Level01HardCode.GDEnemy2Objects1_1final.indexOf(gdjs.Level01HardCode.GDEnemy2Objects2[j]) === -1 )
            gdjs.Level01HardCode.GDEnemy2Objects1_1final.push(gdjs.Level01HardCode.GDEnemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level01HardCode.GDEnemy2Objects1_1final, gdjs.Level01HardCode.GDEnemy2Objects1);
}
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemy2Objects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].addForce(0, 1, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemyObjects1[i].getY() > 608 ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDEnemyObjects1[k] = gdjs.Level01HardCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemyObjects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01HardCode.GDTotalObjects1);
{runtimeScene.getGame().getVariables().get("Live").sub(1);
}{for(var i = 0, len = gdjs.Level01HardCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVMini"), gdjs.Level01HardCode.GDHIVMiniObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVMiniObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVMiniObjects1[i].getY() > 608 ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDHIVMiniObjects1[k] = gdjs.Level01HardCode.GDHIVMiniObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVMiniObjects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVMiniObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01HardCode.GDTotalObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVMiniObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVMiniObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().get("Live").sub(1);
}{for(var i = 0, len = gdjs.Level01HardCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDEnemy2Objects1[i].getY() > 608 ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDEnemy2Objects1[k] = gdjs.Level01HardCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDEnemy2Objects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Total"), gdjs.Level01HardCode.GDTotalObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDTotalObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDTotalObjects1[i].setString(": " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("Live"))));
}
}{runtimeScene.getGame().getVariables().get("Live").sub(1);
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Level01HardCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemyObjects1[i].setX(gdjs.randomInRange(0, 750));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(5);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVMini"), gdjs.Level01HardCode.GDHIVMiniObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVMiniObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVMiniObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVMiniObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(10);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.Level01HardCode.GDEnemy2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level01HardCode.GDPlayerObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
gdjs.Level01HardCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDPlayerObjects1Objects, gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDEnemy2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDEnemy2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level01HardCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].setX(gdjs.randomInRange(0, 750));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDEnemy2Objects1[i].setY(gdjs.randomInRange(-(300), -(100)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).sub(5);
}{for(var i = 0, len = gdjs.Level01HardCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].timerElapsedTime("HIVTimer", 5) ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)) == 1 ) {
        gdjs.Level01HardCode.condition1IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].addForce(0, 100, 1);
}
}{runtimeScene.getGame().getVariables().get("starter").setNumber(2);
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
gdjs.Level01HardCode.condition2IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getY() >= 200 ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)) == 2 ) {
        gdjs.Level01HardCode.condition1IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getX() >= 10 ) {
        gdjs.Level01HardCode.condition2IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}}
}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val && gdjs.Level01HardCode.condition2IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].unpauseTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].addForce(-(50), 0, 1);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getX() <= 10 ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)) == 3 ) {
        gdjs.Level01HardCode.condition1IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].clearForces();
}
}{runtimeScene.getGame().getVariables().get("starter").setNumber(1);
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].addForce(50, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getX() >= 750 ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
gdjs.Level01HardCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("starter")) == 1;
}}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].clearForces();
}
}{runtimeScene.getGame().getVariables().get("starter").setNumber(2);
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
gdjs.Level01HardCode.condition2IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getX() > 750 ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)) == 4 ) {
        gdjs.Level01HardCode.condition1IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition1IsTrue_1.val ) {
{
gdjs.Level01HardCode.condition2IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().get("starter")) == 2;
}}
}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val && gdjs.Level01HardCode.condition2IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].addForce(-(50), -(50), 1);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].setX(750);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].timerElapsedTime("SpawnTimer", 5) ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
gdjs.Level01HardCode.GDHIVMiniObjects1.length = 0;

{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].resetTimer("SpawnTimer");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level01HardCode.mapOfGDgdjs_46Level01HardCode_46GDHIVMiniObjects1Objects, (( gdjs.Level01HardCode.GDHIVSpawnObjects1.length === 0 ) ? 0 :gdjs.Level01HardCode.GDHIVSpawnObjects1[0].getPointX("")) + 10, (( gdjs.Level01HardCode.GDHIVSpawnObjects1.length === 0 ) ? 0 :gdjs.Level01HardCode.GDHIVSpawnObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVMiniObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVMiniObjects1[i].addForce(0, 75, 1);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(3)).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(3)) == 5 ) {
        gdjs.Level01HardCode.condition0IsTrue_0.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].addForce(0, -(1), 1);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].resetTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].pauseTimer("SpawnTimer");
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(5);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(3)).setNumber(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HIVSpawn"), gdjs.Level01HardCode.GDHIVSpawnObjects1);

gdjs.Level01HardCode.condition0IsTrue_0.val = false;
{
{gdjs.Level01HardCode.conditionTrue_1 = gdjs.Level01HardCode.condition0IsTrue_0;
gdjs.Level01HardCode.condition0IsTrue_1.val = false;
gdjs.Level01HardCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getY() <= -(75) ) {
        gdjs.Level01HardCode.condition0IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}if ( gdjs.Level01HardCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level01HardCode.GDHIVSpawnObjects1.length;i<l;++i) {
    if ( gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariableNumber(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)) == 5 ) {
        gdjs.Level01HardCode.condition1IsTrue_1.val = true;
        gdjs.Level01HardCode.GDHIVSpawnObjects1[k] = gdjs.Level01HardCode.GDHIVSpawnObjects1[i];
        ++k;
    }
}
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = k;}}
gdjs.Level01HardCode.conditionTrue_1.val = true && gdjs.Level01HardCode.condition0IsTrue_1.val && gdjs.Level01HardCode.condition1IsTrue_1.val;
}
}if (gdjs.Level01HardCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Level01HardCode.GDHIVSpawnObjects1 */
{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].setY(-(75));
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].setX(330);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].returnVariable(gdjs.Level01HardCode.GDHIVSpawnObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Level01HardCode.GDHIVSpawnObjects1.length ;i < len;++i) {
    gdjs.Level01HardCode.GDHIVSpawnObjects1[i].resetTimer("HIVTimer");
}
}}

}


};

gdjs.Level01HardCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level01HardCode.GDPlayerObjects1.length = 0;
gdjs.Level01HardCode.GDPlayerObjects2.length = 0;
gdjs.Level01HardCode.GDScoreObjects1.length = 0;
gdjs.Level01HardCode.GDScoreObjects2.length = 0;
gdjs.Level01HardCode.GDBulletObjects1.length = 0;
gdjs.Level01HardCode.GDBulletObjects2.length = 0;
gdjs.Level01HardCode.GDEnemyObjects1.length = 0;
gdjs.Level01HardCode.GDEnemyObjects2.length = 0;
gdjs.Level01HardCode.GDBackgroundTileObjects1.length = 0;
gdjs.Level01HardCode.GDBackgroundTileObjects2.length = 0;
gdjs.Level01HardCode.GDLivesObjects1.length = 0;
gdjs.Level01HardCode.GDLivesObjects2.length = 0;
gdjs.Level01HardCode.GDTotalObjects1.length = 0;
gdjs.Level01HardCode.GDTotalObjects2.length = 0;
gdjs.Level01HardCode.GDHIVSpawnObjects1.length = 0;
gdjs.Level01HardCode.GDHIVSpawnObjects2.length = 0;
gdjs.Level01HardCode.GDHIVMiniObjects1.length = 0;
gdjs.Level01HardCode.GDHIVMiniObjects2.length = 0;
gdjs.Level01HardCode.GDEnemy2Objects1.length = 0;
gdjs.Level01HardCode.GDEnemy2Objects2.length = 0;

gdjs.Level01HardCode.eventsList0(runtimeScene);
return;

}

gdjs['Level01HardCode'] = gdjs.Level01HardCode;
