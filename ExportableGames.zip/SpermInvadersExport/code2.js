gdjs.InfoCode = {};
gdjs.InfoCode.GDTextObjects1= [];
gdjs.InfoCode.GDTextObjects2= [];

gdjs.InfoCode.conditionTrue_0 = {val:false};
gdjs.InfoCode.condition0IsTrue_0 = {val:false};
gdjs.InfoCode.condition1IsTrue_0 = {val:false};


gdjs.InfoCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.InfoCode.condition0IsTrue_0.val = false;
{
gdjs.InfoCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.InfoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Text"), gdjs.InfoCode.GDTextObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.InfoCode.GDTextObjects1.length ;i < len;++i) {
    gdjs.InfoCode.GDTextObjects1[i].setTextAlignment("center");
}
}}

}


{



}


{


gdjs.InfoCode.condition0IsTrue_0.val = false;
{
gdjs.InfoCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
}if (gdjs.InfoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Difficulty", false);
}}

}


{



}


{


gdjs.InfoCode.condition0IsTrue_0.val = false;
{
gdjs.InfoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.InfoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.InfoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.InfoCode.GDTextObjects1.length = 0;
gdjs.InfoCode.GDTextObjects2.length = 0;

gdjs.InfoCode.eventsList0(runtimeScene);
return;

}

gdjs['InfoCode'] = gdjs.InfoCode;
